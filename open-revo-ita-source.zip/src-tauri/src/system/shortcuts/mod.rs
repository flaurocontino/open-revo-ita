// OpenRevo - Universal Shortcut Bus (Route 2 Implementation)
// Provides zero-overhead, declarative global shortcuts for plugins and system automation.

pub mod types;
pub mod dispatcher;
pub mod manager;

pub use types::{ParsedKeyCombo, ShortcutAction, ShortcutBinding};
pub use manager::{
    check_match_and_trigger, get_all_shortcuts, load_plugin_shortcuts, register_shortcut,
    unload_plugin_shortcuts, unregister_shortcut,
};

/// Initialize default system shortcuts and load plugin shortcuts
pub fn init_shortcuts() {
    crate::log_info!("SHORTCUTS", "Initializing OpenRevo Universal Shortcut Bus...");

    // Register high-value default shortcuts if none exist
    register_shortcut(ShortcutBinding {
        id: "sys_fan_boost".to_string(),
        name: "Attiva/disattiva il raffreddamento massimo".to_string(),
        combo: "Ctrl+Shift+F".to_string(),
        action: ShortcutAction::ToggleFanBoost,
        osd: true,
        enabled: true,
        swallow: false,
        plugin_id: None,
    });

    register_shortcut(ShortcutBinding {
        id: "sys_cycle_power_mode".to_string(),
        name: "Ciclo tra le modalità prestazioni".to_string(),
        combo: "Ctrl+Shift+M".to_string(),
        action: ShortcutAction::CyclePowerMode,
        osd: true,
        enabled: true,
        swallow: false,
        plugin_id: None,
    });

    register_shortcut(ShortcutBinding {
        id: "sys_toggle_refresh_rate".to_string(),
        name: "Cambio rapido della frequenza dello schermo (alta frequenza/risparmio energetico)".to_string(),
        combo: "Ctrl+Shift+R".to_string(),
        action: ShortcutAction::ToggleRefreshRate,
        osd: true,
        enabled: true,
        swallow: false,
        plugin_id: None,
    });
}
