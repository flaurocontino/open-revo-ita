// OpenRevo - Built-in BRFX Presets (Clean UTF-8)

pub const KAMEHAMEHA: &str = r#"// ==========================================
// @author: OpenRevo Community
// @version: 2.0.0
// @default_speed: 1.2
// @default_scale: 1.0
// @default_direction: 0
// @default_reactive: false
// @default_color: #00F0FF
// ==========================================

fn render_key(kx, ky, ctx) {
    let t_cycle = (ctx.t * ctx.speed * 1.0) % 6.5;
    let y0 = 2.5;
    let dist_y = abs(ky - y0);
    let clash_x = 9.0 + 1.1 * sin(ctx.t * 12.0) * (0.7 + 0.3 * cos(ctx.t * 23.0));

    let r = 0.0;
    let g = 0.0;
    let b = 0.0;

    if t_cycle < 1.2 {
        let head_x = -1.0 + (t_cycle / 1.0) * 23.0;
        let tail_x = 0.0;

        if kx <= head_x && kx >= tail_x {
            let d_head = sqrt((kx - head_x) * (kx - head_x) + dist_y * dist_y);
            let head_radius = 2.5;
            if d_head < head_radius {
                if d_head < 1.1 {
                    r += 255.0;
                    g += 255.0;
                    b += 255.0;
                } else {
                    let outer = (1.0 - (d_head - 1.1) / (head_radius - 1.1));
                    r += 170.0 * outer;
                    g += 235.0 * outer;
                    b += 255.0 * outer;
                }
            }

            let core_h = 0.60;
            if dist_y < core_h {
                let core = pow(1.0 - dist_y / core_h, 2.0);
                r += 240.0 * core;
                g += 250.0 * core;
                b += 255.0 * core;
            }
            let halo_h = 1.25;
            if dist_y < halo_h {
                let halo = 1.0 - dist_y / halo_h;
                let ripple = sin(kx * 4.0 - ctx.t * 30.0) * 0.15;
                r += 20.0 * halo;
                g += clamp(140.0 * halo + 40.0 * ripple, 0.0, 255.0);
                b += 255.0 * halo;
            }

            if kx < 2.5 {
                let flare = max(0.0, 1.0 - kx / 2.5) * max(0.0, 1.0 - dist_y / 1.8);
                r += 60.0 * flare;
                g += 180.0 * flare;
                b += 255.0 * flare;
            }
        }
    } else if t_cycle < 2.4 {
        let p2_t = t_cycle - 1.2;
        let head_x = 19.5 - (p2_t / 1.0) * 23.0;
        let tail_x = 18.5;

        if kx >= head_x && kx <= tail_x {
            let d_head = sqrt((kx - head_x) * (kx - head_x) + dist_y * dist_y);
            let head_radius = 2.5;
            if d_head < head_radius {
                if d_head < 1.1 {
                    r += 255.0;
                    g += 255.0;
                    b += 220.0;
                } else {
                    let outer = (1.0 - (d_head - 1.1) / (head_radius - 1.1));
                    r += 255.0 * outer;
                    g += 215.0 * outer;
                    b += 70.0 * outer;
                }
            }

            let core_h = 0.60;
            if dist_y < core_h {
                let core = pow(1.0 - dist_y / core_h, 2.0);
                r += 255.0 * core;
                g += 250.0 * core;
                b += 160.0 * core;
            }
            let halo_h = 1.25;
            if dist_y < halo_h {
                let halo = 1.0 - dist_y / halo_h;
                let ripple = sin(kx * 4.0 + ctx.t * 30.0) * 0.15;
                r += clamp(255.0 * halo + 40.0 * ripple, 0.0, 255.0);
                g += 160.0 * halo;
                b += 20.0 * halo;
            }

            if kx > 16.0 {
                let flare = max(0.0, (kx - 16.0) / 2.5) * max(0.0, 1.0 - dist_y / 1.8);
                r += 255.0 * flare;
                g += 180.0 * flare;
                b += 40.0 * flare;
            }
        }
    } else if t_cycle < 5.4 {
        let p3_t = t_cycle - 2.4;
        let left_tip = clash_x;
        let right_tip = clash_x;
        if p3_t < 0.4 {
            left_tip = min(clash_x, -1.0 + (p3_t / 0.4) * (clash_x + 1.0));
            right_tip = max(clash_x, 19.5 - (p3_t / 0.4) * (19.5 - clash_x));
        }

        if kx <= left_tip {
            let d_head_l = sqrt((kx - left_tip) * (kx - left_tip) + dist_y * dist_y);
            let head_radius = 2.5;
            if d_head_l < head_radius {
                if d_head_l < 1.1 {
                    r += 255.0;
                    g += 255.0;
                    b += 255.0;
                } else {
                    let outer = (1.0 - (d_head_l - 1.1) / (head_radius - 1.1));
                    r += 170.0 * outer;
                    g += 235.0 * outer;
                    b += 255.0 * outer;
                }
            }

            let core_h = 0.50;
            if dist_y < core_h {
                let core = pow(1.0 - dist_y / core_h, 2.0);
                r += 240.0 * core;
                g += 255.0 * core;
                b += 255.0 * core;
            }
            let halo_h = 1.05;
            if dist_y < halo_h {
                let halo = 1.0 - dist_y / halo_h;
                r += 10.0 * halo;
                g += 130.0 * halo;
                b += 255.0 * halo;
            }
        }

        if kx >= right_tip {
            let d_head_r = sqrt((kx - right_tip) * (kx - right_tip) + dist_y * dist_y);
            let head_radius = 2.5;
            if d_head_r < head_radius {
                if d_head_r < 1.1 {
                    r += 255.0;
                    g += 255.0;
                    b += 220.0;
                } else {
                    let outer = (1.0 - (d_head_r - 1.1) / (head_radius - 1.1));
                    r += 255.0 * outer;
                    g += 215.0 * outer;
                    b += 70.0 * outer;
                }
            }

            let core_h = 0.50;
            if dist_y < core_h {
                let core = pow(1.0 - dist_y / core_h, 2.0);
                r += 255.0 * core;
                g += 245.0 * core;
                b += 180.0 * core;
            }
            let halo_h = 1.05;
            if dist_y < halo_h {
                let halo = 1.0 - dist_y / halo_h;
                r += 255.0 * halo;
                g += 150.0 * halo;
                b += 10.0 * halo;
            }
        }

        let d_clash = sqrt((kx - clash_x) * (kx - clash_x) + dist_y * dist_y * 1.69);
        if p3_t >= 0.4 {
            let vibe = 0.85 + 0.15 * sin(ctx.t * 45.0);
            let r_clash = 2.5 + 0.3 * sin(ctx.t * 18.0);
            if d_clash < r_clash {
                let clash_glow = (1.0 - d_clash / r_clash) * vibe;
                r += 255.0 * clash_glow * 1.3;
                g += 255.0 * clash_glow * 1.3;
                b += 255.0 * clash_glow * 1.3;
            }

            let dx_clash = abs(kx - clash_x);
            if dx_clash < 1.6 {
                let vert = (1.0 - dx_clash / 1.6) * max(0.0, 1.0 - dist_y / 2.8) * vibe;
                if kx <= clash_x {
                    r += 120.0 * vert;
                    g += 220.0 * vert;
                    b += 255.0 * vert;
                } else {
                    r += 255.0 * vert;
                    g += 210.0 * vert;
                    b += 70.0 * vert;
                }
            }

            let spark_seed = sin(kx * 19.37 + ky * 41.29 + ctx.t * 55.0);
            if spark_seed > 0.82 && d_clash < 7.5 {
                let arc_pwr = ((spark_seed - 0.82) / 0.18) * (1.0 - d_clash / 7.5);
                if kx <= clash_x {
                    r += 190.0 * arc_pwr;
                    g += 235.0 * arc_pwr;
                    b += 255.0 * arc_pwr;
                } else {
                    r += 255.0 * arc_pwr;
                    g += 220.0 * arc_pwr;
                    b += 90.0 * arc_pwr;
                }
            }
        }
    } else {
        let p4_t = t_cycle - 5.4;
        let ring_r = p4_t * 16.0;
        let d_center = sqrt((kx - 9.0) * (kx - 9.0) + dist_y * dist_y);
        let ring_dist = abs(d_center - ring_r);
        let fade = max(0.0, 1.0 - p4_t / 1.1);

        if ring_dist < 1.6 {
            let burst = (1.0 - ring_dist / 1.6) * fade;
            r += 255.0 * burst;
            g += 240.0 * burst;
            b += 255.0 * burst;
        }
        if d_center < 3.0 {
            let ember = (1.0 - d_center / 3.0) * fade * fade;
            r += 160.0 * ember;
            g += 190.0 * ember;
            b += 255.0 * ember;
        }
    }

    return [clamp(r, 0.0, 255.0), clamp(g, 0.0, 255.0), clamp(b, 0.0, 255.0)];
}
"#;

pub const CYBER_LOTUS: &str = r#"// ==========================================
// @author: OpenRevo Community
// @version: 2.0.0
// @default_speed: 1.0
// @default_scale: 1.0
// @default_direction: 0
// @default_reactive: false
// @default_color: #00FFFF
// ==========================================

fn render_key(kx, ky, ctx) {
    let center_x = 7.0;
    let center_y = 2.5;
    let dx = (kx - center_x) / ctx.scale;
    let dy = ((ky - center_y) * 1.5) / ctx.scale;
    let r_dist = sqrt(dx * dx + dy * dy);
    let angle = atan2(dy, dx);

    let t = ctx.t * ctx.speed;
    let spin = t * 0.6;

    let breathe = sin(t * 1.5) * 0.4;
    let petal_lobe = cos(6.0 * (angle + spin));
    let petal_r = 3.6 + breathe + 1.6 * petal_lobe;
    let inner_lobe = cos(3.0 * (angle - spin * 1.3));
    let inner_r = 1.8 + 0.5 * inner_lobe;

    let r = 4.0;
    let g = 14.0;
    let b = 26.0;

    if r_dist < inner_r {
        let core_w = 1.0 - r_dist / inner_r;
        let pulse = 0.8 + 0.2 * sin(t * 4.0);
        r += 240.0 * core_w * pulse;
        g += 210.0 * core_w * pulse;
        b += 60.0 * core_w;
    } else if r_dist < petal_r {
        let petal_pos = (r_dist - inner_r) / (petal_r - inner_r);
        let edge_dist = abs(r_dist - petal_r);
        let edge_glow = smoothstep(1.2, 0.0, edge_dist);
        r += 10.0 + 80.0 * petal_pos + 120.0 * edge_glow;
        g += 160.0 + 95.0 * (1.0 - petal_pos);
        b += 255.0 * (1.0 - petal_pos * 0.3);
    } else {
        let ripple = sin(r_dist * 1.6 - t * 3.5);
        if ripple > 0.6 {
            let rip_pwr = ((ripple - 0.6) / 0.4) * max(0.0, 1.0 - r_dist / 12.0) * 0.4;
            r += 10.0 * rip_pwr;
            g += 150.0 * rip_pwr;
            b += 240.0 * rip_pwr;
        }
    }

    let star_freq = 1.1 + sin(kx * 17.31 + ky * 31.17) * 0.5;
    let star_phase = kx * 4.83 + ky * 9.27;
    let p1 = sin(t * star_freq + star_phase);
    let p2 = sin(t * (star_freq * 0.47) + star_phase * 1.618);
    let spark = p1 * p2;

    if spark > 0.60 {
        let star_intensity = pow((spark - 0.60) / 0.40, 2.2);
        let star_seed = sin(kx * 37.19 + ky * 53.81);
        if star_seed > 0.3 {
            r += 140.0 * star_intensity;
            g += 240.0 * star_intensity;
            b += 255.0 * star_intensity;
        } else if star_seed > -0.3 {
            r += 30.0 * star_intensity;
            g += 255.0 * star_intensity;
            b += 190.0 * star_intensity;
        } else {
            r += 255.0 * star_intensity;
            g += 225.0 * star_intensity;
            b += 90.0 * star_intensity;
        }
    }

    return [clamp(r, 0.0, 255.0), clamp(g, 0.0, 255.0), clamp(b, 0.0, 255.0)];
}
"#;

pub const SINGULARITY: &str = r#"// ==========================================
// @author: OpenRevo Community
// @version: 1.0.0
// @default_speed: 1.5
// @default_scale: 1.0
// @default_direction: 0
// @default_reactive: true
// @default_color: #8B5CF6
// ==========================================

fn render_key(kx, ky, ctx) {
    let center_x = 8.5;
    let center_y = 2.5;
    let dx = (kx - center_x) / ctx.scale;
    let dy = ((ky - center_y) * 1.5) / ctx.scale;
    let r_dist = sqrt(dx * dx + dy * dy);
    let angle = atan2(dy, dx);

    let t = ctx.t * ctx.speed;

    let event_horizon = 1.2;
    if r_dist < event_horizon {
        return [0.0, 0.0, 0.0];
    }

    let spin = t * 2.5 - r_dist * 1.2;
    let spiral = sin(angle * 3.0 + spin);

    let r = 0.0;
    let g = 0.0;
    let b = 0.0;

    if r_dist >= event_horizon && r_dist < 2.0 {
        let ring_intensity = (1.0 - (r_dist - event_horizon) / 0.8);
        r = 255.0 * ring_intensity;
        g = 220.0 * ring_intensity;
        b = 255.0 * ring_intensity;
    } else if r_dist < 7.5 {
        let disk_intensity = (1.0 - (r_dist - 2.0) / 5.5) * (0.6 + 0.4 * spiral);
        let doppler = cos(angle);
        if doppler > 0.0 {
            r = (180.0 + 75.0 * doppler) * disk_intensity;
            g = (100.0 + 100.0 * doppler) * disk_intensity;
            b = 255.0 * disk_intensity;
        } else {
            r = 255.0 * disk_intensity;
            g = (120.0 + 80.0 * doppler) * disk_intensity;
            b = 40.0 * disk_intensity;
        }
    }

    return [clamp(r, 0.0, 255.0), clamp(g, 0.0, 255.0), clamp(b, 0.0, 255.0)];
}
"#;

pub const MARQUEE: &str = r#"// ==========================================
// @author: OpenRevo Community
// @version: 1.0.0
// @default_speed: 1.0
// @default_scale: 1.0
// @default_direction: 0
// @default_reactive: false
// @default_color: #00F0FF
// @default_text: I LOVE OPEN-REVO
// ==========================================

fn render_key(kx, ky, ctx) {
    if ky > 5.05 {
        return [0.0, 0.0, 0.0];
    }

    let text = if ctx.text != "" { ctx.text } else { "I LOVE OPEN-REVO" };
    let speed = ctx.speed * 6.5;
    
    let offset_x = kx - 19.0 + ctx.t * speed;
    let hit = sample_text(text, offset_x, ky);

    let mut r = 0.0;
    let mut g = 0.0;
    let mut b = 0.0;

    r += 3.0;
    g += 8.0;
    b += 18.0;

    if hit > 0.05 {
        let hue = ((kx * 12.0 - ctx.t * 30.0) % 360.0);
        if hue < 0.0 { hue += 360.0; }
        
        let c = hsv(hue, 0.95, hit);
        
        let white_core = hit * hit * 60.0;
        r = c[0] + white_core;
        g = c[1] + white_core;
        b = c[2] + white_core;
    }

    return [clamp(r, 0.0, 255.0), clamp(g, 0.0, 255.0), clamp(b, 0.0, 255.0)];
}
"#;

pub fn get_default_presets() -> [(&'static str, &'static str); 4] {
    [
        ("kamehameha.brfx", KAMEHAMEHA),
        ("cyber_lotus.brfx", CYBER_LOTUS),
        ("singularity.brfx", SINGULARITY),
        ("marquee.brfx", MARQUEE),
    ]
}
