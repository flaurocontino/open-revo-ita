// OpenRevo - Shortcut Bus IPC Commands
// Provides frontend and plugins with APIs to query, register, unregister, and manually trigger shortcuts.

use tauri::AppHandle;
use crate::system::shortcuts::{
    get_all_shortcuts, register_shortcut as reg_shortcut, unregister_shortcut as unreg_shortcut,
    ShortcutAction, ShortcutBinding,
};

#[tauri::command]
pub fn get_registered_shortcuts() -> Vec<ShortcutBinding> {
    get_all_shortcuts()
}

#[tauri::command]
pub fn register_custom_shortcut(binding: ShortcutBinding) -> Result<bool, String> {
    if binding.combo.trim().is_empty() {
        return Err("La combinazione di tasti di scelta rapida non può essere vuota".to_string());
    }
    if reg_shortcut(binding) {
        Ok(true)
    } else {
        Err("Errore durante l’analisi o la registrazione della scorciatoia. Controlla il formato dei tasti (ad es. 'Ctrl+Alt+F')".to_string())
    }
}

#[tauri::command]
pub fn unregister_custom_shortcut(id: String) -> Result<bool, String> {
    if unreg_shortcut(&id) {
        Ok(true)
    } else {
        Err(format!("Scorciatoia con ID '{}' non trovata", id))
    }
}

#[tauri::command]
pub fn trigger_shortcut_action(
    app: AppHandle,
    action: ShortcutAction,
    osd: Option<bool>,
) -> Result<(), String> {
    let dummy_binding = ShortcutBinding {
        id: "manual_trigger".to_string(),
        name: "Manual Trigger".to_string(),
        combo: "".to_string(),
        action,
        osd: osd.unwrap_or(true),
        enabled: true,
        swallow: false,
        plugin_id: None,
    };
    crate::system::shortcuts::dispatcher::dispatch_action(app, dummy_binding);
    Ok(())
}
