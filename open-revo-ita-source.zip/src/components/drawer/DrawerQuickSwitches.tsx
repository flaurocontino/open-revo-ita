import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { HardwareState } from '../../types/hardware';
import {
  Fan,
  Camera,
  CameraOff,
  Mic,
  MicOff,
  Lock,
  Unlock,
  Coffee,
  Moon,
  Laptop,
} from 'lucide-react';

interface QuickSwitchesState {
  wifi: boolean;
  bluetooth: boolean;
  touchpad: boolean;
  camera: boolean;
  mic: boolean;
  keep_awake: boolean;
}

import { ModelCapabilities } from '../../plugins/plugin_manifest';

interface DrawerQuickSwitchesProps {
  status: HardwareState;
  capabilities?: ModelCapabilities;
  checkOemGuard: (action: () => void) => void;
  onToggleFanBoost: () => void;
  onToggleWinKey: () => void;
}

export const DrawerQuickSwitches: React.FC<DrawerQuickSwitchesProps> = ({
  status,
  capabilities: _capabilities,
  checkOemGuard,
  onToggleFanBoost,
  onToggleWinKey,
}) => {
  const [switches, setSwitches] = useState<{
    camera: boolean;
    mic: boolean;
    keep_awake: boolean;
  }>({
    camera: true,
    mic: true,
    keep_awake: false,
  });

  const syncSwitches = () => {
    invoke<QuickSwitchesState>('get_device_switches')
      .then((res) => {
        if (res) {
          setSwitches({
            camera: res.camera,
            mic: res.mic,
            keep_awake: res.keep_awake,
          });
        }
      })
      .catch((err) => console.warn('Failed to get quick switches:', err));
  };

  const toggleSwitch = async (name: 'camera' | 'mic' | 'keep_awake') => {
    const current = switches[name];
    const target = !current;
    setSwitches((prev) => ({ ...prev, [name]: target }));
    try {
      await invoke('set_device_switch', { switchName: name, enable: target });
    } catch (err) {
      console.warn(`Toggle ${name} error:`, err);
      setSwitches((prev) => ({ ...prev, [name]: current }));
    }
  };

  useEffect(() => {
    syncSwitches();
    window.addEventListener('focus', syncSwitches);

    let unlistenCam: (() => void) | undefined;
    let unlistenMic: (() => void) | undefined;
    let unlistenKeepAwake: (() => void) | undefined;

    listen<boolean>('camera-state-changed', (e) => {
      setSwitches((p) => ({ ...p, camera: e.payload }));
    }).then((fn) => { unlistenCam = fn; });

    listen<boolean>('mic-state-changed', (e) => {
      setSwitches((p) => ({ ...p, mic: e.payload }));
    }).then((fn) => { unlistenMic = fn; });

    listen<boolean>('keep-awake-state-changed', (e) => {
      setSwitches((p) => ({ ...p, keep_awake: e.payload }));
    }).then((fn) => { unlistenKeepAwake = fn; });

    return () => {
      window.removeEventListener('focus', syncSwitches);
      if (unlistenCam) unlistenCam();
      if (unlistenMic) unlistenMic();
      if (unlistenKeepAwake) unlistenKeepAwake();
    };
  }, []);

  return (
    <>
      {/* =========================================================
          Riga 7: Matrice interruttori rapidi (6 pulsanti: Ventole Max, Fotocamera, Microfono, Blocco Win, No Sospensione, Spegni Schermo)
          ========================================================= */}
      <div className="m-quick-grid">
        {/* 1. Ventole Max */}
        {status.support_flags?.has_fan_boost !== false && (
          <button
            className={`m-quick-btn ${status.fan_boost ? 'active' : ''}`}
            onClick={() => checkOemGuard(onToggleFanBoost)}
            title={status.fan_boost ? 'Doppia ventola alla massima velocità attiva (clicca per disattivare)' : 'Attiva subito la velocità massima della doppia ventola'}
          >
            <Fan size={16} className={status.fan_boost ? 'animate-spin' : ''} />
            <span className="m-quick-btn-label">Ventole Max</span>
          </button>
        )}

        {/* 2. Interruttore fotocamera */}
        <button
          className={`m-quick-btn ${switches.camera ? 'active' : ''}`}
          onClick={() => toggleSwitch('camera')}
          title={switches.camera ? 'Fotocamera accesa e alimentata (clicca per disabilitare via hardware)' : 'Fotocamera disabilitata via hardware (clicca per attivare)'}
        >
          {switches.camera ? <Camera size={16} /> : <CameraOff size={16} />}
          <span className="m-quick-btn-label">{switches.camera ? 'Fotocamera' : 'Cam Spenta'}</span>
        </button>

        {/* 3. Interruttore microfono */}
        <button
          className={`m-quick-btn ${switches.mic ? 'active' : ''}`}
          onClick={() => toggleSwitch('mic')}
          title={switches.mic ? 'Microfono attivo (clicca per silenziare)' : 'Microfono silenziato (clicca per riattivare)'}
        >
          {switches.mic ? <Mic size={16} /> : <MicOff size={16} />}
          <span className="m-quick-btn-label">{switches.mic ? 'Microfono' : 'Mic Muto'}</span>
        </button>

        {/* 4. Blocco tasto Win */}
        <button
          className={`m-quick-btn ${status.win_key_locked ? 'active' : ''}`}
          onClick={onToggleWinKey}
          title={status.win_key_locked ? 'Tasto Windows bloccato contro tocchi accidentali (clicca per sbloccare)' : 'Tasto Windows sbloccato (clicca per bloccare)'}
        >
          {status.win_key_locked ? <Lock size={16} /> : <Unlock size={16} />}
          <span className="m-quick-btn-label">{status.win_key_locked ? 'Win Blocco' : 'Sblocco Win'}</span>
        </button>

        {/* 5. Evita sospensione */}
        <button
          className={`m-quick-btn ${switches.keep_awake ? 'active' : ''}`}
          onClick={() => toggleSwitch('keep_awake')}
          title={switches.keep_awake ? ' Modalità sempre attivo attivata (impedisce sospensione e blocco schermo)' : 'Modalità sempre attivo disattivata (segue il piano energetico di sistema)'}
        >
          <Coffee size={16} />
          <span className="m-quick-btn-label">{switches.keep_awake ? 'Sempre attivo' : 'No sospensione'}</span>
        </button>

        {/* 6. Spegni schermo (protezione 3 secondi) */}
        <button
          className="m-quick-btn"
          onClick={async () => {
            try {
              await invoke('turn_off_screen');
            } catch (e) {
              console.error('Failed to turn off screen:', e);
            }
          }}
          title="Spegne subito lo schermo (3 sec. di blocco contro risvegli accidentali, ideale con Sempre On)"
        >
          <Moon size={16} />
          <span className="m-quick-btn-label">Spegni Schermo</span>
        </button>
      </div>

      {/* Barra inferiore modello dispositivo e stato hardware */}
      <div
        style={{
          marginTop: '3px',
          marginBottom: '0px',
          padding: '4px 9px',
          borderRadius: '6px',
          background: 'rgba(255, 255, 255, 0.025)',
          border: '1px solid rgba(255, 255, 255, 0.06)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          fontSize: '10px',
          color: 'var(--text-dim)',
          flexShrink: 0,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', overflow: 'hidden' }}>
          <Laptop size={13} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
          <span
            style={{
              color: '#cbd5e1',
              fontWeight: 600,
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              maxWidth: '220px',
            }}
            title={status.model_name || 'MECHREVO Gaming Laptop'}
          >
            {status.model_name || 'MECHREVO Gaming Laptop'}
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '5px', flexShrink: 0, paddingLeft: '8px' }}>
          <div style={{ width: '5px', height: '5px', borderRadius: '50%', background: '#34d399', boxShadow: '0 0 5px #34d399' }} />
          <span style={{ fontSize: '9.5px', color: '#6ee7b7', fontWeight: 700, letterSpacing: '0.04em' }}>READY</span>
        </div>
      </div>
    </>
  );
};
