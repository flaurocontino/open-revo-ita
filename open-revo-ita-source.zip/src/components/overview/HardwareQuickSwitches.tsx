import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import {
  Wifi,
  Bluetooth,
  Camera,
  Mic,
  MicOff,
  Coffee,
  Moon,
  Monitor,
} from 'lucide-react';
import { HardwareState } from '../../types/hardware';
import { OsdConfig } from '../SystemSettingsView';

export interface QuickSwitchesState {
  wifi: boolean;
  bluetooth: boolean;
  touchpad: boolean;
  camera: boolean;
  mic: boolean;
  osd: boolean;
  win_key: boolean;
  fn_lock: boolean;
  keep_awake: boolean;
}

interface HardwareQuickSwitchesProps {
  status: HardwareState;
  osdConfig: OsdConfig;
  onUpdateOsdConfig: (cfg: OsdConfig) => void;
}

export const HardwareQuickSwitches: React.FC<HardwareQuickSwitchesProps> = ({
  status,
  osdConfig,
  onUpdateOsdConfig: handleUpdateOsdConfig,
}) => {
  const [switches, setSwitches] = useState<QuickSwitchesState>({
    wifi: true,
    bluetooth: true,
    touchpad: true,
    camera: true,
    mic: true,
    osd: true,
    win_key: status.win_key_locked,
    fn_lock: false,
    keep_awake: false,
  });

  const [togglingSwitches, setTogglingSwitches] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const fetchSwitches = () => {
      invoke<QuickSwitchesState>('get_device_switches')
        .then((res) => {
          if (res) setSwitches(res);
        })
        .catch(() => {});
    };
    fetchSwitches();
    window.addEventListener('focus', fetchSwitches);

    let unlistenTouchpad: (() => void) | undefined;
    let unlistenBt: (() => void) | undefined;
    let unlistenWifi: (() => void) | undefined;
    let unlistenCam: (() => void) | undefined;
    let unlistenMic: (() => void) | undefined;
    let unlistenWinLock: (() => void) | undefined;
    let unlistenFnLock: (() => void) | undefined;
    let unlistenKeepAwake: (() => void) | undefined;

    listen<boolean>('touchpad-state-changed', (event) => {
      setSwitches((prev) => ({ ...prev, touchpad: event.payload }));
    }).then((fn) => { unlistenTouchpad = fn; });

    listen<boolean>('bluetooth-state-changed', (event) => {
      setSwitches((prev) => ({ ...prev, bluetooth: event.payload }));
    }).then((fn) => { unlistenBt = fn; });

    listen<boolean>('wifi-state-changed', (event) => {
      setSwitches((prev) => ({ ...prev, wifi: event.payload }));
    }).then((fn) => { unlistenWifi = fn; });

    listen<boolean>('camera-state-changed', (event) => {
      setSwitches((prev) => ({ ...prev, camera: event.payload }));
    }).then((fn) => { unlistenCam = fn; });

    listen<boolean>('mic-state-changed', (event) => {
      setSwitches((prev) => ({ ...prev, mic: event.payload }));
    }).then((fn) => { unlistenMic = fn; });

    listen<boolean>('win-lock-state-changed', (event) => {
      setSwitches((prev) => ({ ...prev, win_key: event.payload }));
    }).then((fn) => { unlistenWinLock = fn; });

    listen<boolean>('fn-lock-state-changed', (event) => {
      setSwitches((prev) => ({ ...prev, fn_lock: event.payload }));
    }).then((fn) => { unlistenFnLock = fn; });

    listen<boolean>('keep-awake-state-changed', (event) => {
      setSwitches((prev) => ({ ...prev, keep_awake: event.payload }));
    }).then((fn) => { unlistenKeepAwake = fn; });

    return () => {
      window.removeEventListener('focus', fetchSwitches);
      if (unlistenTouchpad) unlistenTouchpad();
      if (unlistenBt) unlistenBt();
      if (unlistenWifi) unlistenWifi();
      if (unlistenCam) unlistenCam();
      if (unlistenMic) unlistenMic();
      if (unlistenWinLock) unlistenWinLock();
      if (unlistenFnLock) unlistenFnLock();
      if (unlistenKeepAwake) unlistenKeepAwake();
    };
  }, []);

  useEffect(() => {
    setSwitches((prev) => ({ ...prev, win_key: status.win_key_locked }));
  }, [status.win_key_locked]);

  const handleToggleSwitch = async (name: keyof QuickSwitchesState) => {
    if (togglingSwitches[name]) return;
    setTogglingSwitches((prev) => ({ ...prev, [name]: true }));
    const nextVal = !switches[name];
    setSwitches((prev) => ({ ...prev, [name]: nextVal }));

    if (name === 'osd') {
      await handleUpdateOsdConfig({ ...osdConfig, enabled: nextVal });
      setTogglingSwitches((prev) => ({ ...prev, [name]: false }));
      return;
    }

    try {
      const res = await invoke<boolean>('set_device_switch', { switchName: name, enable: nextVal });
      if (typeof res === 'boolean') {
        setSwitches((prev) => ({ ...prev, [name]: res }));
      }
    } catch (e) {
      console.error('Failed to toggle switch:', name, e);
      setSwitches((prev) => ({ ...prev, [name]: !nextVal }));
    } finally {
      setTogglingSwitches((prev) => ({ ...prev, [name]: false }));
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div style={{ width: '4px', height: '14px', background: '#38bdf8', borderRadius: '2px' }} />
          <span style={{ fontSize: '13px', fontWeight: 700, letterSpacing: '0.04em', color: '#f1f5f9' }}>
            Interruttori Rapidi Hardware
          </span>
        </div>
        <span style={{ fontSize: '11px', color: 'var(--text-dim)' }}>
          Controllo diretto periferiche e tasti rapidi
        </span>
      </div>

      <div className="oem-switch-grid">
        {/* 1. Interruttore Wi-Fi */}
        <div
          onClick={() => handleToggleSwitch('wifi')}
          title="Attiva / Disattiva rete wireless (Wi-Fi)"
          className={`oem-switch-card ${switches.wifi ? 'active' : ''} ${togglingSwitches.wifi ? 'opacity-60 cursor-wait' : ''}`}
        >
          <div className="oem-bracket-tl" />
          <div className="oem-bracket-tr" />
          <div className="oem-bracket-bl" />
          <div className="oem-bracket-br" />

          <div className="oem-icon-badge">
            <Wifi className="w-4 h-4" />
          </div>
          <div className="oem-switch-title">WIFI</div>
        </div>

        {/* 2. Interruttore Bluetooth */}
        <div
          onClick={() => handleToggleSwitch('bluetooth')}
          title="Attiva / Disattiva Bluetooth"
          className={`oem-switch-card ${switches.bluetooth ? 'active' : ''} ${togglingSwitches.bluetooth ? 'opacity-60 cursor-wait' : ''}`}
        >
          <div className="oem-bracket-tl" />
          <div className="oem-bracket-tr" />
          <div className="oem-bracket-bl" />
          <div className="oem-bracket-br" />

          <div className="oem-icon-badge">
            <Bluetooth className="w-4 h-4" />
          </div>
          <div className="oem-switch-title">Bluetooth</div>
        </div>

        {/* 3. Interruttore Touchpad */}
        <div
          onClick={() => handleToggleSwitch('touchpad')}
          title="Attiva / Disattiva Touchpad"
          className={`oem-switch-card ${switches.touchpad ? 'active' : ''} ${togglingSwitches.touchpad ? 'opacity-60 cursor-wait' : ''}`}
        >
          <div className="oem-bracket-tl" />
          <div className="oem-bracket-tr" />
          <div className="oem-bracket-bl" />
          <div className="oem-bracket-br" />

          <div className="oem-icon-badge">
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="4" width="18" height="16" rx="2" />
              <line x1="3" y1="14" x2="21" y2="14" />
              <line x1="12" y1="14" x2="12" y2="20" />
            </svg>
          </div>
          <div className="oem-switch-title">Touchpad</div>
        </div>

        {/* 4. Interruttore Fotocamera */}
        <div
          onClick={() => handleToggleSwitch('camera')}
          title="Attiva / Disattiva webcam integrata"
          className={`oem-switch-card ${switches.camera ? 'active' : ''} ${togglingSwitches.camera ? 'opacity-60 cursor-wait' : ''}`}
        >
          <div className="oem-bracket-tl" />
          <div className="oem-bracket-tr" />
          <div className="oem-bracket-bl" />
          <div className="oem-bracket-br" />

          <div className="oem-icon-badge">
            <Camera className="w-4 h-4" />
          </div>
          <div className="oem-switch-title">Fotocamera</div>
        </div>

        {/* 5. Interruttore Microfono globale */}
        <div
          onClick={() => handleToggleSwitch('mic')}
          title="Attiva / Silenzia microfono globale"
          className={`oem-switch-card ${switches.mic ? 'active' : ''} ${togglingSwitches.mic ? 'opacity-60 cursor-wait' : ''}`}
        >
          <div className="oem-bracket-tl" />
          <div className="oem-bracket-tr" />
          <div className="oem-bracket-bl" />
          <div className="oem-bracket-br" />

          <div className="oem-icon-badge">
            {switches.mic ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4 text-rose-400" />}
          </div>
          <div className="oem-switch-title">{switches.mic ? 'Microfono' : 'Mic Muto'}</div>
        </div>

        {/* 6. Interruttore OSD */}
        <div
          onClick={() => handleToggleSwitch('osd')}
          title="Attiva / Disattiva avvisi OSD a schermo"
          className={`oem-switch-card ${switches.osd ? 'active' : ''} ${togglingSwitches.osd ? 'opacity-60 cursor-wait' : ''}`}
        >
          <div className="oem-bracket-tl" />
          <div className="oem-bracket-tr" />
          <div className="oem-bracket-bl" />
          <div className="oem-bracket-br" />

          <div className="oem-icon-badge">
            <Monitor className="w-4 h-4" />
          </div>
          <div className="oem-switch-title">Avvisi OSD</div>
        </div>

        {/* 7. Tasto Win */}
        {status.support_flags?.has_win_lock !== false && (
          <div
            onClick={() => handleToggleSwitch('win_key')}
            title="Modalità Gioco: blocca / sblocca tasto Windows"
            className={`oem-switch-card ${switches.win_key ? 'active' : ''} ${togglingSwitches.win_key ? 'opacity-60 cursor-wait' : ''}`}
          >
            <div className="oem-bracket-tl" />
            <div className="oem-bracket-tr" />
            <div className="oem-bracket-bl" />
            <div className="oem-bracket-br" />

            <div className="oem-icon-badge">
              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="currentColor">
                <path d="M0 3.449L9.75 2.1v9.451H0m10.949-9.602L24 0v11.4H10.949M0 12.6h9.75v9.451L0 20.699M10.949 12.6H24V24l-12.9-1.801" />
              </svg>
            </div>
            <div className="oem-switch-title">Blocco Win</div>
          </div>
        )}

        {/* 8. Blocco Fn */}
        {status.support_flags?.has_fn_lock !== false && (
          <div
            onClick={() => handleToggleSwitch('fn_lock')}
            title={switches.fn_lock ? 'Blocco Fn attivo: usa combinazione Fn' : 'Blocco Fn disattivo: tasti F1-F12 diretti'}
            className={`oem-switch-card ${switches.fn_lock ? 'active' : ''} ${togglingSwitches.fn_lock ? 'opacity-60 cursor-wait' : ''}`}
          >
            <div className="oem-bracket-tl" />
            <div className="oem-bracket-tr" />
            <div className="oem-bracket-bl" />
            <div className="oem-bracket-br" />

            <div className="oem-icon-badge">
              <span style={{ fontSize: '12px', fontWeight: 900, letterSpacing: '0.04em' }}>FN</span>
            </div>
            <div className="oem-switch-title">{switches.fn_lock ? 'Blocco Fn' : 'F1-F12'}</div>
          </div>
        )}

        {/* 9. Sempre attivo (No Sospensione) */}
        <div
          onClick={() => handleToggleSwitch('keep_awake')}
          title="Sempre attivo: impedisce lo spegnimento dello schermo e la sospensione durante download o rendering"
          className={`oem-switch-card ${switches.keep_awake ? 'active' : ''} ${togglingSwitches.keep_awake ? 'opacity-60 cursor-wait' : ''}`}
        >
          <div className="oem-bracket-tl" />
          <div className="oem-bracket-tr" />
          <div className="oem-bracket-bl" />
          <div className="oem-bracket-br" />

          <div className="oem-icon-badge">
            <Coffee className="w-4 h-4" />
          </div>
          <div className="oem-switch-title">No Sospensione</div>
        </div>

        {/* 10. Spegni schermo (protezione 3 secondi) */}
        <div
          onClick={async () => {
            try {
              await invoke('turn_off_screen');
            } catch (e) {
              console.error('Failed to turn off screen:', e);
            }
          }}
          title="Spegni schermo: spegne subito il display (3 sec. di protezione contro risvegli accidentali)"
          className="oem-switch-card cursor-pointer"
        >
          <div className="oem-bracket-tl" />
          <div className="oem-bracket-tr" />
          <div className="oem-bracket-bl" />
          <div className="oem-bracket-br" />

          <div className="oem-icon-badge">
            <Moon className="w-4 h-4" />
          </div>
          <div className="oem-switch-title">Spegni Schermo</div>
        </div>
      </div>
    </div>
  );
};
