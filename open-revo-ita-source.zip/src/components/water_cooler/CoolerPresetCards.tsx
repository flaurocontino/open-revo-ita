import React from 'react';
import { Sparkles, ShieldCheck, Zap } from 'lucide-react';

interface CoolerPresetCardsProps {
  strategy?: string;
  liveMaxTemp: number;
  liveInterpolated: { duty: number; volt: number };
  onUpdateStrategy: (strategy: string) => void;
}

export const CoolerPresetCards: React.FC<CoolerPresetCardsProps> = ({
  strategy,
  liveMaxTemp,
  liveInterpolated,
  onUpdateStrategy,
}) => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', flexShrink: 0 }}>
      <div style={{ fontSize: '10.5px', fontWeight: 700, color: 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span>Modalità strategia del profilo di raffreddamento</span>
        <span style={{ fontSize: '10px', color: 'var(--text-dim)', fontWeight: 500, display: 'inline-flex', alignItems: 'center', gap: '3px' }}>
          {strategy === 'custom' ? (
            <>
              <Sparkles size={11} style={{ color: 'var(--status-warn)' }} /> Stato personalizzato manuale attivo
            </>
          ) : (
            'Seleziona Adattivo intelligente per regolare automaticamente pompa e ventola'
          )}
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.35fr 1fr 1fr 1fr', gap: '7px' }}>
        {}
        <div
          onClick={() => onUpdateStrategy('smart')}
          className={`cooler-strat-card cooler-strat-smart ${strategy === 'smart' ? 'active' : ''}`}
          style={{
            background: strategy === 'smart' ? 'var(--status-info-dim)' : 'var(--surface-badge)',
            border: strategy === 'smart' ? '1px solid var(--status-info)' : '1px solid var(--border-subtle)',
            boxShadow: strategy === 'smart' ? '0 0 16px rgba(56, 189, 248, 0.25)' : 'none',
            borderRadius: 'var(--radius-sm)',
            padding: '6px 9px',
            cursor: 'pointer',
            display: 'flex',
            flexDirection: 'column',
            gap: '2px',
            transition: 'all var(--transition-fast)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span className="cooler-strat-title" style={{ fontSize: '11px', fontWeight: 800, color: 'var(--status-info)', display: 'inline-flex', alignItems: 'center', gap: '3px' }}>
              <ShieldCheck size={13} /> Adattivo intelligente
            </span>
            <span
              className="cooler-strat-badge"
              style={{
                fontSize: '8px',
                fontWeight: 800,
                padding: '1px 4px',
                borderRadius: 'var(--radius-xs)',
                background: 'var(--status-info-dim)',
                color: 'var(--status-info)',
              }}
            >
              Controllo termico
            </span>
          </div>
          <div style={{ fontSize: '9.5px', color: 'var(--text-muted)', lineHeight: 1.3 }}>
            Regolazione dinamica in base alla temperatura centrale; ventola <strong style={{ color: 'var(--status-ok)' }}>&lt;55 °C</strong>
          </div>
          <div className="cooler-strat-sub" style={{ fontSize: '9px', fontWeight: 700, color: 'var(--status-info)', display: 'inline-flex', alignItems: 'center', gap: '3px' }}>
            <Zap size={10} /> : {liveMaxTemp}°C → Ventola {liveInterpolated.duty}% | pompa {
              liveInterpolated.volt >= 11 || liveInterpolated.volt === 3
                ? 'limiteEstremo'
                : liveInterpolated.volt === 0
                ? ''
                : 'crociera standard'
            }
          </div>
        </div>

        {}
        <div
          onClick={() => onUpdateStrategy('quiet')}
          className={`cooler-strat-card cooler-strat-quiet ${strategy === 'quiet' ? 'active' : ''}`}
          style={{
            background: strategy === 'quiet' ? 'var(--status-info-dim)' : 'var(--surface-badge)',
            border: strategy === 'quiet' ? '1px solid var(--status-info)' : '1px solid var(--border-subtle)',
            borderRadius: 'var(--radius-sm)',
            padding: '6px 9px',
            cursor: 'pointer',
            display: 'flex',
            flexDirection: 'column',
            gap: '2px',
            transition: 'all var(--transition-fast)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span className="cooler-strat-title" style={{ fontSize: '11px', fontWeight: 800, color: 'var(--status-info)' }}>Silenziosostrategia</span>
            <span className="cooler-strat-badge" style={{ fontSize: '8px', fontWeight: 800, padding: '1px 4px', borderRadius: 'var(--radius-xs)', background: 'var(--surface-pill)', color: 'var(--text-muted)' }}></span>
          </div>
          <div style={{ fontSize: '9.5px', color: 'var(--text-muted)', lineHeight: 1.3 }}>Modalità crociera: pompa standard + 40% ventola</div>
          <div style={{ fontSize: '9px', color: 'var(--text-dim)', marginTop: '1px' }}></div>
        </div>

        {}
        <div
          onClick={() => onUpdateStrategy('balance')}
          className={`cooler-strat-card cooler-strat-balance ${strategy === 'balance' ? 'active' : ''}`}
          style={{
            background: strategy === 'balance' ? 'var(--border-glow)' : 'var(--surface-badge)',
            border: strategy === 'balance' ? '1px solid var(--color-brand)' : '1px solid var(--border-subtle)',
            borderRadius: 'var(--radius-sm)',
            padding: '6px 9px',
            cursor: 'pointer',
            display: 'flex',
            flexDirection: 'column',
            gap: '2px',
            transition: 'all var(--transition-fast)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span className="cooler-strat-title" style={{ fontSize: '11px', fontWeight: 800, color: 'var(--color-brand)' }}>Strategia bilanciata</span>
            <span className="cooler-strat-badge" style={{ fontSize: '8px', fontWeight: 800, padding: '1px 4px', borderRadius: 'var(--radius-xs)', background: 'var(--surface-pill)', color: 'var(--text-muted)' }}></span>
          </div>
          <div style={{ fontSize: '9.5px', color: 'var(--text-muted)', lineHeight: 1.3 }}>Modalità crociera: pompa standard + 65% ventola</div>
          <div style={{ fontSize: '9px', color: 'var(--text-dim)', marginTop: '1px' }}>Raffreddamento continuo</div>
        </div>

        {/* Velocissimo estremo */}
        <div
          onClick={() => onUpdateStrategy('performance')}
          className={`cooler-strat-card cooler-strat-perf ${strategy === 'performance' ? 'active' : ''}`}
          style={{
            background: strategy === 'performance' ? 'var(--status-error-dim)' : 'var(--surface-badge)',
            border: strategy === 'performance' ? '1px solid var(--status-error)' : '1px solid var(--border-subtle)',
            borderRadius: 'var(--radius-sm)',
            padding: '6px 9px',
            cursor: 'pointer',
            display: 'flex',
            flexDirection: 'column',
            gap: '2px',
            transition: 'all var(--transition-fast)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span className="cooler-strat-title" style={{ fontSize: '11px', fontWeight: 800, color: 'var(--status-error)' }}>Velocissimo estremo</span>
            <span className="cooler-strat-badge" style={{ fontSize: '8px', fontWeight: 800, padding: '1px 4px', borderRadius: 'var(--radius-xs)', background: 'var(--status-error-dim)', color: 'var(--status-error)' }}>prestazioni massime</span>
          </div>
          <div style={{ fontSize: '9.5px', color: 'var(--text-muted)', lineHeight: 1.3 }}>Limite estremo: pompa + 100% ventola</div>
          <div style={{ fontSize: '9px', color: 'var(--text-dim)', marginTop: '1px' }}>Limite raffreddamento prestazioni</div>
        </div>
      </div>
    </div>
  );
};
