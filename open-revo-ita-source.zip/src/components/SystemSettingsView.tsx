import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import {
  FolderOpen,
  Trash2,
  AlertTriangle,
  RotateCcw,
  Crosshair,
  Globe,
  Gauge,
  Lightbulb,
  Zap,
  Cpu,
  Cable,
  Sliders,
  Droplets,
  Download,
  RefreshCw,
  HardDrive,
} from 'lucide-react';
import { HardwareState } from '../types/hardware';
import { RevBadge, RevSwitch } from './ui';
import { ModelCapabilities } from '../plugins/plugin_manifest';

export interface OsdConfig {
  enabled: boolean;
  theme: 'cinema' | 'fade' | 'pill';
  scale: string;
  position: 'top-left' | 'bottom-center' | 'center';
}

export interface SystemSettingsViewProps {
  status: HardwareState;
  osdConfig: OsdConfig;
  onUpdateOsdConfig: (cfg: OsdConfig) => void;
  onToggleWinKey?: () => void;
  onToggleAutostart: () => void;
  onToggleWaterCooler?: (enabled: boolean) => void;
  moduleToggles?: Record<string, boolean>;
  onToggleModule?: (id: string, enabled: boolean) => void;
  capabilities?: ModelCapabilities;
  previewMode?: 'real' | 'thin_light' | 'gaming';
  onPreviewFormFactor?: (mode: 'real' | 'thin_light' | 'gaming') => void;
}

export const SystemSettingsView: React.FC<SystemSettingsViewProps> = ({
  status,
  osdConfig,
  onUpdateOsdConfig: handleUpdateOsdConfig,
  onToggleWinKey: _onToggleWinKey,
  onToggleAutostart,
  onToggleWaterCooler: _onToggleWaterCooler,
  moduleToggles: _moduleToggles,
  onToggleModule: _onToggleModule,
  capabilities,
  previewMode = 'real',
  onPreviewFormFactor,
}) => {

  const [logStatus, setLogStatus] = useState<{
    visible: boolean;
    enabled: boolean;
    level: number;
    path: string;
    filter?: string | null;
  }>({
    visible: false,
    enabled: false,
    level: 1,
    path: '',
    filter: null,
  });

  const [wakeWindowMode, setWakeWindowMode] = useState<'remember' | 'mini' | 'full'>('remember');
  const [miniAutoHide, setMiniAutoHide] = useState(true);
  const [unlockBatteryLimit, setUnlockBatteryLimit] = useState(!!status.unlock_battery_power_limit);
  const [showUnlockBatteryConfirm, setShowUnlockBatteryConfirm] = useState(false);
  const [togglingUnlockBattery, setTogglingUnlockBattery] = useState(false);

  useEffect(() => {
    if (typeof status.unlock_battery_power_limit === 'boolean') {
      setUnlockBatteryLimit(status.unlock_battery_power_limit);
    }
  }, [status.unlock_battery_power_limit]);

  const handleToggleUnlockBattery = async (nextVal: boolean) => {
    if (nextVal) {
      setShowUnlockBatteryConfirm(true);
    } else {
      setTogglingUnlockBattery(true);
      try {
        await invoke('set_unlock_battery_power_limit', { enable: false });
        setUnlockBatteryLimit(false);
      } catch (err: any) {
        alert('Errore durante la disattivazione del limite di alimentazione a batteria: ' + err);
      } finally {
        setTogglingUnlockBattery(false);
      }
    }
  };

  const handleConfirmUnlockBattery = async () => {
    setTogglingUnlockBattery(true);
    try {
      await invoke('set_unlock_battery_power_limit', { enable: true });
      setUnlockBatteryLimit(true);
      setShowUnlockBatteryConfirm(false);
    } catch (err: any) {
      alert('Errore durante l’attivazione del limite di alimentazione a batteria: ' + err);
    } finally {
      setTogglingUnlockBattery(false);
    }
  };

  useEffect(() => {
    invoke<string>('get_wake_window_mode')
      .then((mode) => {
        if (mode === 'remember' || mode === 'mini' || mode === 'full') {
          setWakeWindowMode(mode);
        }
      })
      .catch(() => { });

    invoke<boolean>('get_mini_auto_hide')
      .then((val) => {
        if (typeof val === 'boolean') {
          setMiniAutoHide(val);
        }
      })
      .catch(() => { });
  }, []);

  const handleUpdateWakeMode = async (mode: 'remember' | 'mini' | 'full') => {
    setWakeWindowMode(mode);
    try {
      await invoke('set_wake_window_mode', { mode });
    } catch (e) {
      console.error('Failed to set wake window mode:', e);
    }
  };

  const handleToggleMiniAutoHide = async (enabled: boolean) => {
    setMiniAutoHide(enabled);
    try {
      await invoke('set_mini_auto_hide', { enabled });
    } catch (e) {
      console.error('Failed to set mini drawer auto hide:', e);
    }
  };

  useEffect(() => {
    invoke<any>('get_log_status')
      .then((res) => {
        if (res) {
          setLogStatus({
            visible: !!res.visible,
            enabled: !!res.enabled,
            level: typeof res.level === 'number' ? res.level : 1,
            path: res.path || '',
            filter: res.filter || null,
          });
        }
      })
      .catch(() => { });
  }, []);

  const handleSetLogLevel = async (lvl: number) => {
    try {
      const res = await invoke<any>('set_log_level', { level: lvl });
      if (res) {
        setLogStatus({
          visible: !!res.visible,
          enabled: !!res.enabled,
          level: typeof res.level === 'number' ? res.level : lvl,
          path: res.path || logStatus.path,
          filter: res.filter || null,
        });
      }
    } catch (_) { }
  };

  const handleSetLogFilter = async (filter: string | null) => {
    try {
      const res = await invoke<any>('set_log_filter', { filter: filter || null });
      if (res) {
        setLogStatus({
          visible: !!res.visible,
          enabled: !!res.enabled,
          level: typeof res.level === 'number' ? res.level : logStatus.level,
          path: res.path || logStatus.path,
          filter: res.filter || null,
        });
      }
    } catch (_) { }
  };

  const handleOpenLog = () => {
    invoke('open_log_file').catch(() => { });
  };

  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [clearingData, setClearingData] = useState(false);

  // User Data Directory & Migration
  const [dataDirInfo, setDataDirInfo] = useState<{ path: string; mode: string } | null>(null);
  const [showMigrateModal, setShowMigrateModal] = useState(false);
  const [migrateTargetPath, setMigrateTargetPath] = useState('');
  const [migratingData, setMigratingData] = useState(false);

  const fetchUserDataDirInfo = async () => {
    try {
      const info = await invoke<{ path: string; mode: string }>('get_user_data_dir_info');
      setDataDirInfo(info);
    } catch (_) { }
  };

  useEffect(() => {
    fetchUserDataDirInfo();
  }, []);

  const handleOpenUserDataDir = async () => {
    try {
      await invoke('open_user_data_dir');
    } catch (err: any) {
      alert('Impossibile aprire la cartella dati utente: ' + err);
    }
  };

  const handleClearUserData = async () => {
    setClearingData(true);
    try {
      await invoke('clear_user_data_dir');
      setShowClearConfirm(false);
      alert('Dati utente di OpenRevo cancellati correttamente!\nRiavvia l’applicazione per reinizializzare la configurazione predefinita.');
      fetchUserDataDirInfo();
    } catch (err: any) {
      alert('Errore durante la cancellazione dei dati: ' + err);
    } finally {
      setClearingData(false);
    }
  };

  const handleMigrateData = async () => {
    if (!migrateTargetPath.trim()) return;
    setMigratingData(true);
    try {
      await invoke('migrate_user_data_dir', { targetPath: migrateTargetPath.trim() });
      await fetchUserDataDirInfo();
      setShowMigrateModal(false);
      setMigrateTargetPath('');
      alert('La cartella dati utente è stata migrata in: ' + migrateTargetPath.trim());
    } catch (err: any) {
      alert('Errore durante la migrazione della cartella dati: ' + err);
    } finally {
      setMigratingData(false);
    }
  };

  // Auto-Updater State & Handlers
  interface UpdateCheckResult {
    has_update: boolean;
    current_version: string;
    current_commit: string;
    latest_version: string;
    latest_commit: string;
    display_version: string;
    notes: string;
    chosen_source: string;
    asset_type: string;
    filename: string;
    download_url: string;
    size: number;
    sha256: string;
  }

  interface DownloadProgressPayload {
    downloaded: number;
    total: number;
    percentage: number;
    speed_bytes_per_sec: number;
  }

  const [checkingUpdate, setCheckingUpdate] = useState(false);
  const [updateResult, setUpdateResult] = useState<UpdateCheckResult | null>(null);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [downloadingUpdate, setDownloadingUpdate] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<DownloadProgressPayload | null>(null);

  useEffect(() => {
    let unlisten: (() => void) | undefined;
    listen<DownloadProgressPayload>('updater-progress', (event) => {
      setDownloadProgress(event.payload);
    }).then((fn) => {
      unlisten = fn;
    });
    return () => {
      if (unlisten) unlisten();
    };
  }, []);

  const handleCheckForUpdates = async (silent: boolean = false) => {
    setCheckingUpdate(true);
    try {
      const res = await invoke<UpdateCheckResult>('check_for_updates_cmd', { preferredSource: null });
      setUpdateResult(res);
      if (res.has_update) {
        setShowUpdateModal(true);
      } else if (!silent) {
        alert(`Questa è già la versione più recente (${res.display_version || res.current_version})!\nNon sono disponibili aggiornamenti.`);
      }
    } catch (err: any) {
      if (!silent) {
        alert('Errore durante il controllo degli aggiornamenti: ' + err);
      }
    } finally {
      setCheckingUpdate(false);
    }
  };

  const handleDownloadAndInstall = async () => {
    if (!updateResult) return;
    setDownloadingUpdate(true);
    setDownloadProgress({ downloaded: 0, total: updateResult.size, percentage: 0, speed_bytes_per_sec: 0 });
    try {
      await invoke('download_and_install_update_cmd', {
        downloadUrl: updateResult.download_url,
        expectedSha256: updateResult.sha256,
        filename: updateResult.filename,
        isInstaller: updateResult.asset_type === 'installer',
      });
    } catch (err: any) {
      alert('Errore durante il download o l’installazione dell’aggiornamento: ' + err);
      setDownloadingUpdate(false);
    }
  };

  const [powerSchemes, setPowerSchemes] = useState<{ guid: string; name: string; is_active: boolean }[]>([]);
  const [switchingScheme, setSwitchingScheme] = useState(false);

  const fetchPowerSchemes = async () => {
    try {
      const list = await invoke<any[]>('get_windows_power_schemes');
      if (list && Array.isArray(list)) {
        setPowerSchemes(list);
      }
    } catch (_) { }
  };

  React.useEffect(() => {
    fetchPowerSchemes();
  }, []);

  const handleSwitchPowerScheme = async (guid: string) => {
    if (!guid) return;
    setSwitchingScheme(true);
    try {
      await invoke('set_active_windows_power_scheme', { guid });
      await fetchPowerSchemes();
    } catch (e: any) {
      alert('Errore durante il cambio del profilo energetico: ' + e);
    } finally {
      setSwitchingScheme(false);
    }
  };

  const [restoringPowerPlan, setRestoringPowerPlan] = useState(false);
  const [showRestorePlanConfirm, setShowRestorePlanConfirm] = useState(false);
  const [restorePlanMsg, setRestorePlanMsg] = useState<string | null>(null);

  const handleRestoreOfficialPowerPlan = async () => {
    setShowRestorePlanConfirm(false);
    setRestoringPowerPlan(true);
    try {
      const res = await invoke<string>('restore_official_power_plan');
      await fetchPowerSchemes();
      setRestorePlanMsg(res || 'Ripristino riuscito del piano energetico ufficiale di fabbrica e della pianificazione PPM!');
      setTimeout(() => setRestorePlanMsg(null), 5000);
    } catch (e: any) {
      console.error('Failed to restore official power plan:', e);
      setRestorePlanMsg('Errore di ripristino: ' + String(e));
      setTimeout(() => setRestorePlanMsg(null), 5000);
    } finally {
      setRestoringPowerPlan(false);
    }
  };

  return (
    <div className="sys-page">
      <div className="glass-card">
        <h3 className="sys-section-title">Interruttori funzionalità di sistema</h3>
        <div className="sys-rows">

          {}
          <div className="quick-row" style={{ alignItems: 'center' }}>
            <div>
              <div className="sys-row-label">
                <span>Informazioni OSD su schermo</span>
                <RevBadge variant="info">HUD</RevBadge>
              </div>
              <div className="sys-row-desc">
                Durante il cambio con il collegamento rapido, mostra lo stato sullo schermo. Sono disponibili 3 stili, dimensioni e posizioni.
              </div>
            </div>
            <div className="sys-row-controls">
              {}
              <div className="sys-row-controls">
                <span style={{ fontSize: '11px', color: 'var(--text-dim)' }}>Stile</span>
                <select
                  value={osdConfig.theme}
                  onChange={(e) => handleUpdateOsdConfig({ ...osdConfig, theme: e.target.value as any })}
                  className="rev-select"
                >
                  <option value="cinema">Sottotitoli cinema</option>
                  <option value="fade">Sfuma a destra</option>
                  <option value="pill">Capsula satinata</option>
                </select>
              </div>

              {}
              <div className="sys-row-controls">
                <span style={{ fontSize: '11px', color: 'var(--text-dim)' }}>Dimensione</span>
                <select
                  value={osdConfig.scale}
                  onChange={(e) => handleUpdateOsdConfig({ ...osdConfig, scale: e.target.value })}
                  className="rev-select"
                >
                  <option value="80%">80%</option>
                  <option value="100%">100%</option>
                  <option value="120%">120%</option>
                  <option value="140%">140%</option>
                </select>
              </div>

              {}
              <div className="sys-row-controls">
                <span style={{ fontSize: '11px', color: 'var(--text-dim)' }}>Posizione</span>
                <select
                  value={osdConfig.position}
                  onChange={(e) => handleUpdateOsdConfig({ ...osdConfig, position: e.target.value as any })}
                  className="rev-select"
                >
                  <option value="top-left">In alto a sinistra</option>
                  <option value="bottom-center">In basso al centro</option>
                  <option value="center">Centro dello schermo</option>
                </select>
              </div>

              {}
              <button
                onClick={async () => {
                  try {
                    await invoke('trigger_osd_preview');
                  } catch (err) {
                    console.error('Failed to trigger OSD preview:', err);
                  }
                }}
                className="toggle-btn"
                title="Mostra subito un'anteprima OSD sullo schermo con la configurazione attuale"
                style={{ borderColor: 'rgba(99, 102, 241, 0.3)', color: '#a5b4fc' }}
              >
                Anteprima
              </button>

              {}
              <RevSwitch
                checked={osdConfig.enabled}
                onChange={(enabled) => handleUpdateOsdConfig({ ...osdConfig, enabled })}
              />
            </div>
          </div>

          {}
          <div className="quick-row">
            <div>
              <div className="sys-row-label">Avvio automatico (riduci a icona nell'area di notifica)</div>
              <div className="sys-row-desc">Carica automaticamente i driver e l'ultima configurazione all'avvio</div>
            </div>
            <RevSwitch
              checked={!!status.autostart}
              onChange={onToggleAutostart}
            />
          </div>

          {}
          <div className="quick-row" style={{ alignItems: 'center' }}>
            <div>
              <div className="sys-row-label">
                <span>Disabilita limite alimentazione a batteria</span>
                <RevBadge variant={unlockBatteryLimit ? 'warning' : 'default'}>
                  {unlockBatteryLimit ? 'Limite rimosso (a tuo rischio)' : 'Limite di sicurezza predefinito'}
                </RevBadge>
                <RevBadge variant="accent">Power Gating</RevBadge>
              </div>
              <div className="sys-row-desc">
                Consente di passare liberamente alla modalità estrema o personalizzata quando l'alimentatore o il cavo Type-C sono scollegati, senza forzare il passaggio alla modalità bilanciata. Utile per configurare consumi ridotti o prestazioni a batteria.
              </div>
            </div>
            <div className="sys-row-controls">
              <RevSwitch
                checked={unlockBatteryLimit}
                disabled={togglingUnlockBattery}
                onChange={handleToggleUnlockBattery}
              />
            </div>
          </div>

          {/* Aspetto pannello al risveglio */}
          <div className="quick-row" style={{ alignItems: 'center' }}>
            <div>
              <div className="sys-row-label">
                <span>Aspetto pannello al risveglio</span>
                <RevBadge variant="info">Window</RevBadge>
              </div>
              <div className="sys-row-desc">
                Scegli come mostrare l'interfaccia quando viene riaperta dall'area di notifica o in background: ricorda l'ultimo stato o usa sempre la modalità preferita.
              </div>
            </div>
            <div className="sys-row-controls">
              <div
                style={{
                  display: 'inline-flex',
                  gap: '4px',
                  background: 'var(--surface-overlay)',
                  padding: '3px',
                  borderRadius: 'var(--radius-md)',
                  border: '1px solid var(--border-subtle)',
                }}
              >
                <button
                  type="button"
                  className={`toggle-btn ${wakeWindowMode === 'remember' ? 'active-indigo' : ''}`}
                  onClick={() => handleUpdateWakeMode('remember')}
                  style={{ padding: '4px 10px', fontSize: '11px', whiteSpace: 'nowrap' }}
                  title="Ricorda lo stato della finestra alla chiusura: pannello completo o cassetto compatto"
                >
                  Memorizza ultimo aspetto
                </button>
                <button
                  type="button"
                  className={`toggle-btn ${wakeWindowMode === 'mini' ? 'active-indigo' : ''}`}
                  onClick={() => handleUpdateWakeMode('mini')}
                  style={{ padding: '4px 10px', fontSize: '11px', whiteSpace: 'nowrap' }}
                  title="All'apertura, mostra sempre il cassetto compatto nell'angolo in basso a destra"
                >
                  Usa sempre il cassetto mini
                </button>
                <button
                  type="button"
                  className={`toggle-btn ${wakeWindowMode === 'full' ? 'active-indigo' : ''}`}
                  onClick={() => handleUpdateWakeMode('full')}
                  style={{ padding: '4px 10px', fontSize: '11px', whiteSpace: 'nowrap' }}
                  title="All'apertura, espandi il pannello di controllo completo (960×740), centrato o nella posizione memorizzata"
                >
                  Usa sempre il pannello completo
                </button>
              </div>
            </div>
          </div>

          {}
          <div className="quick-row" style={{ alignItems: 'center' }}>
            <div>
              <div className="sys-row-label">
                <span>Comprimi automaticamente il cassetto compatto facendo clic all'esterno</span>
                <RevBadge variant="info">Mini Drawer</RevBadge>
              </div>
              <div className="sys-row-desc">
                In modalità cassetto compatto, facendo clic sul desktop o su un'altra finestra il cassetto viene richiuso automaticamente. Il pannello completo non è interessato.
              </div>
            </div>
            <div className="sys-row-controls">
              <RevSwitch
                checked={miniAutoHide}
                onChange={handleToggleMiniAutoHide}
              />
            </div>
          </div>

          {/* Gestione dati */}
          <div className="quick-row">
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div className="sys-row-label">Gestione archivio dati</div>
                <RevBadge variant={dataDirInfo?.mode === 'portable' ? 'success' : dataDirInfo?.mode === 'custom' ? 'warning' : 'accent'}>
                  {dataDirInfo?.mode === 'portable'
                    ? 'Cartella portatile (./data)'
                    : dataDirInfo?.mode === 'custom'
                      ? 'Percorso personalizzato (data_dir.ptr)'
                      : 'AppData standard (%APPDATA%)'}
                </RevBadge>
              </div>
              <div className="sys-row-desc" title={dataDirInfo?.path || ''}>
                {dataDirInfo?.path
                  ? `Cartella attuale: ${dataDirInfo.path}`
                  : 'Gestisci i profili utente, gli effetti della tastiera, i plugin scaricati, i temi e gli altri file persistenti'}
              </div>
            </div>
            <div className="sys-row-controls">
              <button
                onClick={handleOpenUserDataDir}
                className="toggle-btn"
                title="Apri la cartella dei dati utente attuale in Esplora file"
              >
                <FolderOpen size={12} />
                <span>Apri cartella</span>
              </button>
              <button
                onClick={() => {
                  setMigrateTargetPath(dataDirInfo?.path || '');
                  setShowMigrateModal(true);
                }}
                className="toggle-btn"
                title="Migra i profili senza perdita di dati e crea un reindirizzamento"
              >
                <HardDrive size={12} />
                <span>Migra archivio</span>
              </button>
              <button
                onClick={() => setShowClearConfirm(true)}
                className="toggle-btn danger"
                title="Elimina tutti i dati e i profili utente di OpenRevo"
              >
                <Trash2 size={12} />
                <span>Cancella dati</span>
              </button>
            </div>
          </div>

          {}
          <div className="quick-row">
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div className="sys-row-label">Versione software e aggiornamenti</div>
                <RevBadge variant="info">
                  {updateResult?.display_version || 'v0.9.3'}
                </RevBadge>
              </div>
              <div className="sys-row-desc">
                Supporta il download simultaneo da GitHub e dal mirror Gitee; compatibile con le versioni installata e portatile.
              </div>
            </div>
            <div className="sys-row-controls">
              <button
                onClick={() => handleCheckForUpdates(false)}
                disabled={checkingUpdate}
                className={`toggle-btn ${checkingUpdate ? 'active-indigo' : ''}`}
                title="Controlla subito la disponibilità di nuove versioni su GitHub e Gitee"
              >
                <RefreshCw size={12} className={checkingUpdate ? 'spin-icon' : ''} />
                <span>{checkingUpdate ? 'Ricerca in corso...' : 'Controlla aggiornamenti'}</span>
              </button>
            </div>
          </div>

          {/* Piano energetico base Windows */}
          <div className="quick-row">
            <div>
              <div className="sys-row-label">
                <span>Piano energetico base Windows</span>
                <RevBadge variant="success">powercfg</RevBadge>
                {restorePlanMsg && (
                  <RevBadge variant={restorePlanMsg.includes('Errore') ? 'error' : 'success'}>
                    {restorePlanMsg}
                  </RevBadge>
                )}
              </div>
              <div className="sys-row-desc">
                Piani di alimentazione di sistema. I profili di undervolt e underclock creati dall'utente vengono mantenuti e possono essere selezionati in qualsiasi momento.
              </div>
            </div>
            <div className="sys-row-controls">
              <button
                onClick={() => setShowRestorePlanConfirm(true)}
                disabled={restoringPowerPlan}
                className="toggle-btn danger"
                style={{ padding: '4px 10px', fontSize: '11px', minWidth: 'auto' }}
                title="Solo per notebook gaming Tongfang/Bolongda: rimuove i blocchi di frequenza anomali e le temperature elevate in standby, ripristina il profilo bilanciato ufficiale e la gestione originale"
              >
                {restoringPowerPlan ? 'Ripristino in corso...' : 'Ripara/ripristina piano'}
              </button>
              <select
                value={powerSchemes.find((s) => s.is_active)?.guid || ''}
                onChange={(e) => handleSwitchPowerScheme(e.target.value)}
                disabled={switchingScheme || restoringPowerPlan}
                className="rev-select"
                style={{ maxWidth: '190px' }}
              >
                {powerSchemes.map((s) => (
                  <option key={s.guid} value={s.guid}>
                    {s.name} {s.is_active ? '(attivo)' : ''}
                  </option>
                ))}
              </select>
              <button
                onClick={fetchPowerSchemes}
                disabled={restoringPowerPlan}
                className="toggle-btn"
                style={{ padding: '4px 7px', minWidth: 'auto' }}
                title="Aggiorna l'elenco dei profili di alimentazione di sistema"
              >
                <RotateCcw size={12} />
              </button>
            </div>
          </div>

          {}
          {logStatus.visible && (
            <>
              <div className="quick-row">
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <div className="sys-row-label">Livello dei log di esecuzione e diagnostica</div>
                    <RevBadge variant={logStatus.level === 2 ? 'accent' : 'success'}>
                      {logStatus.level === 2 ? 'Tutti i log (tracciamento dettagliato)' : 'Log degli errori (solo errori e arresti anomali)'}
                    </RevBadge>
                    {logStatus.level === 2 && (
                      <RevBadge
                        variant={logStatus.filter ? 'warning' : 'default'}
                        title={
                          logStatus.filter
                            ? `Mostra solo i log dei moduli corrispondenti a [${logStatus.filter}] (rumore ad alta frequenza filtrato)`
                            : 'Nessun filtro impostato: mostra tutti i log dei moduli'
                        }
                      >
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '3px' }}>
                          {logStatus.filter
                            ? <><Crosshair size={10} /> Filtro: {logStatus.filter}</>
                            : <><Globe size={10} /> Tutti i moduli</>}
                        </span>
                      </RevBadge>
                    )}
                  </div>
                  <div className="sys-row-desc">
                    Avviato con parametri di debug; al termine della diagnosi puoi chiudere questa sezione per risparmiare spazio su disco.
                  </div>
                </div>
                <div className="sys-row-controls">
                  <button
                    onClick={() => handleSetLogLevel(logStatus.level === 2 ? 1 : 2)}
                    className={`toggle-btn ${logStatus.level === 2 ? 'active-indigo' : ''}`}
                    style={{ minWidth: '78px' }}
                  >
                    {logStatus.level === 2 ? 'Passa ai log degli errori' : 'Passa a tutti i log'}
                  </button>
                  <button
                    onClick={handleOpenLog}
                    className="toggle-btn"
                    style={{ minWidth: '78px' }}
                    title={logStatus.path || 'Apri file di log'}
                  >
                    Visualizza log
                  </button>
                  <button
                    onClick={() => handleSetLogLevel(0)}
                    className="toggle-btn"
                    style={{ minWidth: '65px', color: 'var(--text-dim)' }}
                    title="Chiudi i log e nascondili nuovamente agli utenti standard"
                  >
                    Chiudi e nascondi
                  </button>
                </div>
              </div>

              {}
              {logStatus.level === 2 && (
                <div
                  className="quick-row"
                  style={{ backgroundColor: 'rgba(0, 0, 0, 0.15)', borderTop: '1px solid var(--border-subtle)' }}
                >
                  <div>
                    <div className="sys-row-label" style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                      Filtro preciso dei moduli diagnostici (parametro secondario)
                    </div>
                    <div className="sys-row-desc">
                      Selezionando i moduli si filtrano migliaia di letture EC ad alta frequenza; supportato dalla riga di comando{' '}
                      <code style={{ color: 'var(--color-brand)' }}>--debug=</code>
                    </div>
                  </div>
                  <div className="sys-chip-row">
                    {[
                      { label: 'Tutti', value: null, Icon: Globe },
                      { label: 'Water cooler esterno', value: 'cooler', Icon: Droplets },
                      { label: 'Tracciamento personalizzato', value: 'custom', Icon: Gauge },
                      { label: 'RGB e streaming', value: 'light', Icon: Lightbulb },
                      { label: 'Alimentazione e ventole', value: 'power', Icon: Zap },
                      { label: 'EC di sistema', value: 'ec', Icon: Cpu },
                      { label: 'Periferiche', value: 'device', Icon: Cable },
                      { label: 'Finestra e sistema', value: 'ui', Icon: Sliders },
                    ].map((item) => {
                      const isActive =
                        (!item.value && !logStatus.filter) ||
                        (item.value && logStatus.filter?.toLowerCase() === item.value);
                      const ItemIcon = item.Icon;
                      return (
                        <button
                          key={item.label}
                          onClick={() => handleSetLogFilter(item.value)}
                          className={`toggle-btn ${isActive ? 'active-indigo' : ''}`}
                          style={{ fontSize: '10px', padding: '2px 8px', minWidth: 'auto', borderRadius: 'var(--radius-xs)' }}
                        >
                          <ItemIcon size={11} />
                          <span>{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </>
          )}



          {}
          {capabilities?.is_debug_mode && onPreviewFormFactor && (
            <div className="sys-card sys-card--highlight">
              <div className="sys-card-header">
                <div className="sys-card-title">
                  <Sliders className="sys-card-icon" />
                  <span>Anteprima in tempo reale di configurazione e capacità del modello (modalità sviluppatore)</span>
                </div>
                <RevBadge color="amber">--debug </RevBadge>
              </div>
              <div className="sys-card-desc">
                Consente agli sviluppatori di simulare nell'interfaccia i diversi layout hardware senza modificare la comunicazione sottostante (ad esempio, nascondere la GPU dedicata o il water cooler sui notebook sottili).
              </div>

              <div className="sys-rows">
                <div className="quick-row">
                  <div className="sys-row-label">
                    <span>Configurazione simulata attuale</span>
                    <span className="sys-row-desc">
                      {previewMode === 'real'
                        ? `Hardware reale: ${capabilities.name || 'Adattivo'} (${capabilities.form_factor || 'gaming'})`
                        : previewMode === 'thin_light'
                          ? 'Simulazione: notebook sottile 14" (GPU integrata + senza water cooler + retroilluminazione monocolore)'
                          : 'Simulazione: notebook gaming standard (GPU dedicata + water cooler + tutte le funzioni)'}
                    </span>
                  </div>
                  <div className="sys-row-controls">
                    <button
                      className={`toggle-btn ${previewMode === 'real' ? 'active-emerald' : ''}`}
                      onClick={() => onPreviewFormFactor('real')}
                    >
                      Dispositivo reale
                    </button>
                    <button
                      className={`toggle-btn ${previewMode === 'thin_light' ? 'active-cyan' : ''}`}
                      onClick={() => onPreviewFormFactor('thin_light')}
                    >
                      Notebook sottile 14"
                    </button>
                    <button
                      className={`toggle-btn ${previewMode === 'gaming' ? 'active-indigo' : ''}`}
                      onClick={() => onPreviewFormFactor('gaming')}
                    >
                      Configurazione notebook gaming
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>

      {}
      {showClearConfirm && (
        <div
          className="sys-modal-backdrop"
          onClick={() => !clearingData && setShowClearConfirm(false)}
        >
          <div
            className="sys-modal-card danger"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sys-modal-header">
              <div className="sys-modal-icon-badge danger">
                <AlertTriangle size={20} />
              </div>
              <div>
                <div className="sys-modal-title">Cancellare tutti i dati utente?</div>
                <div className="sys-modal-subtitle">Questa operazione eliminerà definitivamente la cartella dei dati utente locali</div>
              </div>
            </div>

            <div className="sys-modal-body">
              <div className="sys-modal-warning-label">
                ⚠️ Attenzione: i seguenti elementi verranno eliminati definitivamente:
              </div>
              <ul className="sys-modal-list">
                <li>Modalità e profili di alimentazione creati o modificati dall'utente</li>
                <li>Effetti luminosi, script di animazione e profili della tastiera creati dall'utente</li>
                <li>Plugin di terze parti e temi personalizzati scaricati</li>
                <li>Nomi personalizzati e mappature dei modelli (models.json)</li>
              </ul>
            </div>

            <div className="sys-modal-actions">
              <button
                disabled={clearingData}
                onClick={() => setShowClearConfirm(false)}
                className="toggle-btn"
              >
                Annulla
              </button>
              <button
                disabled={clearingData}
                onClick={handleClearUserData}
                className="toggle-btn btn-danger-solid"
              >
                {clearingData ? 'Eliminazione in corso...' : 'Conferma eliminazione'}
              </button>
            </div>
          </div>
        </div>
      )}

      {}
      {showUnlockBatteryConfirm && (
        <div
          className="sys-modal-backdrop"
          onClick={() => !togglingUnlockBattery && setShowUnlockBatteryConfirm(false)}
        >
          <div
            className="sys-modal-card danger"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sys-modal-header">
              <div className="sys-modal-icon-badge danger">
                <AlertTriangle size={20} />
              </div>
              <div>
                <div className="sys-modal-title">Avviso sui rischi della rimozione dei limiti di alimentazione a batteria</div>
                <div className="sys-modal-subtitle">Scarica hardware e sicurezza della batteria</div>
              </div>
            </div>

            <div className="sys-modal-body">
              <div className="sys-modal-warning-label">
                ⚠️ Il firmware ufficiale disabilita per impostazione predefinita le modalità ad alto consumo quando si usa la batteria. Considera i seguenti rischi:
              </div>
              <ul className="sys-modal-list">
                <li><strong>Intervento della protezione da sovracorrente</strong>: la batteria di un notebook gaming eroga molta meno potenza dell'alimentatore originale. Un carico elevato a batteria può attivare la protezione BMS, causando uno spegnimento o un riavvio improvviso.</li>
                <li><strong>Riduzione della durata della batteria</strong>: una scarica prolungata ad alta potenza genera calore e accelera l'usura della batteria al litio.</li>
                <li><strong>Nessun passaggio automatico a una modalità meno potente</strong>: scollegando l'alimentatore, il sistema manterrà la modalità estrema o esperto attuale.</li>
                <li><strong>Uso consigliato</strong>: puoi usare questa opzione per ridurre il consumo di CPU/GPU e la temperatura e aumentare l'autonomia. Evita giochi 3D impegnativi o rendering intensivo quando usi la batteria.</li>
              </ul>
            </div>

            <div className="sys-modal-actions">
              <button
                disabled={togglingUnlockBattery}
                onClick={() => setShowUnlockBatteryConfirm(false)}
                className="toggle-btn"
              >
                Annulla
              </button>
              <button
                disabled={togglingUnlockBattery}
                onClick={handleConfirmUnlockBattery}
                className="toggle-btn btn-danger-solid"
              >
                {togglingUnlockBattery ? 'Attivazione...' : 'Ho compreso i rischi, conferma'}
              </button>
            </div>
          </div>
        </div>
      )}

      {}
      {showRestorePlanConfirm && (
        <div
          className="sys-modal-backdrop"
          onClick={() => !restoringPowerPlan && setShowRestorePlanConfirm(false)}
        >
          <div
            className="sys-modal-card"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sys-modal-header">
              <div className="sys-modal-icon-badge warning">
                <RotateCcw size={20} />
              </div>
              <div>
                <div className="sys-modal-title">Ripara e ripristina il piano di alimentazione originale</div>
                <div className="sys-modal-subtitle">Ripristina il comportamento della console ufficiale e risolve le temperature elevate e i blocchi di frequenza in standby</div>
              </div>
            </div>

            <div className="sys-modal-body">
              <div className="sys-modal-warning-label">
                💡 Questa operazione eseguirà i seguenti interventi di ripristino sicuri (secondo gli standard originali):
              </div>
              <ul className="sys-modal-list">
                <li><strong>Risoluzione del surriscaldamento in standby</strong>: ripristina le impostazioni del cursore delle prestazioni, la sospensione dei core della CPU (Core Parking) e gli stati Package C-State per ridurre il calore accumulato.</li>
                <li><strong>Rimozione dei limiti di frequenza residui</strong>: elimina dai profili di alimentazione i limiti di frequenza statici, come i blocchi a 0,8 GHz o 25 W.</li>
                <li><strong>Ripristino del pacchetto OEM</strong>: installa il pacchetto PPM appropriato per il modello attuale (pacchetto AMD Provisioning di Bolongda o strategia PPM Tongfang).</li>
                <li><strong>Attivazione del profilo bilanciato ufficiale</strong>: ripristina il profilo bilanciato standard di Windows. I piani di alimentazione personalizzati vengono mantenuti.</li>
              </ul>
            </div>

            <div className="sys-modal-actions">
              <button
                disabled={restoringPowerPlan}
                onClick={() => setShowRestorePlanConfirm(false)}
                className="toggle-btn"
              >
                Annulla
              </button>
              <button
                disabled={restoringPowerPlan}
                onClick={handleRestoreOfficialPowerPlan}
                className="toggle-btn active-indigo"
              >
                {restoringPowerPlan ? 'Ripristino in corso...' : 'Conferma ripristino'}
              </button>
            </div>
          </div>
        </div>
      )}
      {}
      {showMigrateModal && (
        <div
          className="sys-modal-backdrop"
          onClick={() => !migratingData && setShowMigrateModal(false)}
        >
          <div
            className="sys-modal-card"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sys-modal-header">
              <div className="sys-modal-icon-badge info">
                <HardDrive size={20} />
              </div>
              <div>
                <div className="sys-modal-title">Migra la cartella dei dati utente</div>
                <div className="sys-modal-subtitle">Sposta i profili di configurazione in un nuovo percorso e crea un reindirizzamento automatico</div>
              </div>
            </div>

            <div className="sys-modal-body">
              <div className="sys-modal-warning-label">
                💡 Il programma copierà tutti i dati utente nella nuova cartella senza perdita di dati e creerà un file di reindirizzamento (data_dir.ptr) nella posizione originale.
              </div>
              <div style={{ marginTop: '10px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                  Percorso assoluto della cartella di destinazione (ad esempio: D:\OpenRevoData):
                </label>
                <input
                  type="text"
                  value={migrateTargetPath}
                  onChange={(e) => setMigrateTargetPath(e.target.value)}
                  disabled={migratingData}
                  placeholder="D:\OpenRevoData"
                  style={{
                    width: '100%',
                    padding: '8px 10px',
                    fontSize: '12px',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid var(--border-medium)',
                    background: 'var(--surface-overlay)',
                    color: 'var(--text-primary)',
                    outline: 'none',
                  }}
                />
              </div>
            </div>

            <div className="sys-modal-actions">
              <button
                disabled={migratingData}
                onClick={() => setShowMigrateModal(false)}
                className="toggle-btn"
              >
                Annulla
              </button>
              <button
                disabled={migratingData || !migrateTargetPath.trim()}
                onClick={handleMigrateData}
                className="toggle-btn active-indigo"
              >
                {migratingData ? 'Migrazione in corso...' : 'Conferma migrazione'}
              </button>
            </div>
          </div>
        </div>
      )}

      {}
      {showUpdateModal && updateResult && (
        <div
          className="sys-modal-backdrop"
          onClick={() => !downloadingUpdate && setShowUpdateModal(false)}
        >
          <div
            className="sys-modal-card"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sys-modal-header">
              <div className="sys-modal-icon-badge info">
                <Download size={20} />
              </div>
              <div>
                <div className="sys-modal-title">
                  Nuova versione disponibile {updateResult.display_version || updateResult.latest_version}
                </div>
                <div className="sys-modal-subtitle">
                  Fonte più veloce: {updateResult.chosen_source === 'gitee' ? 'Mirror Gitee accelerato' : updateResult.chosen_source === 'local_mock' ? 'Simulazione locale' : 'Fonte ufficiale GitHub'} · Tipo di distribuzione: {updateResult.asset_type === 'installer' ? 'Aggiornamento tramite installer' : 'Aggiornamento rapido della versione portatile'}
                </div>
              </div>
            </div>

            <div className="sys-modal-body">
              <div style={{ marginBottom: '8px', fontSize: '11px', color: 'var(--text-muted)' }}>
                Registro aggiornamenti e note sulle modifiche:
              </div>
              <div className="updater-changelog-box">
                {updateResult.notes || 'Nessuna nota di aggiornamento disponibile.'}
              </div>

              <div style={{ marginTop: '10px', fontSize: '11px', color: 'var(--text-dim)', display: 'flex', justifyContent: 'space-between' }}>
                <span>File distribuzione: {updateResult.filename}</span>
                <span>Dimensione: {(updateResult.size / (1024 * 1024)).toFixed(2)} MB</span>
              </div>

              {downloadingUpdate && downloadProgress && (
                <div className="updater-progress-container">
                  <div className="updater-progress-bar-bg">
                    <div
                      className="updater-progress-bar-fill"
                      style={{ width: `${Math.min(100, Math.max(0, downloadProgress.percentage))}%` }}
                    />
                  </div>
                  <div className="updater-progress-stats">
                    <span>
                      {(downloadProgress.downloaded / (1024 * 1024)).toFixed(2)} MB / {(downloadProgress.total / (1024 * 1024)).toFixed(2)} MB
                    </span>
                    <span>
                      {(downloadProgress.speed_bytes_per_sec / (1024 * 1024)).toFixed(2)} MB/s ({downloadProgress.percentage.toFixed(1)}%)
                    </span>
                  </div>
                </div>
              )}
            </div>

            <div className="sys-modal-actions">
              <button
                disabled={downloadingUpdate}
                onClick={() => setShowUpdateModal(false)}
                className="toggle-btn"
              >
                Più tardi
              </button>
              <button
                disabled={downloadingUpdate}
                onClick={handleDownloadAndInstall}
                className="toggle-btn active-indigo"
              >
                {downloadingUpdate ? 'Download dell’aggiornamento...' : 'Aggiorna subito'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
