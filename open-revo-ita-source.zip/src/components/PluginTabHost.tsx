import React, { useState, useEffect, useRef } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { HardwareState, PowerMode } from '../types/hardware';
import { CustomPluginItem } from './PluginsView';
import { AlertCircle, FolderOpen, RotateCcw, Loader2, ExternalLink, Play, Square } from 'lucide-react';

export interface PluginServiceStatus {
  plugin_id: string;
  status: 'running' | 'starting' | 'stopped' | 'error';
  pid?: number;
  port?: number;
  code?: string;
  message?: string;
  detail?: string;
}

interface PluginTabHostProps {
  plugin: CustomPluginItem;
  status: HardwareState;
}

export const PluginTabHost: React.FC<PluginTabHostProps> = ({ plugin, status }) => {
  const [htmlContent, setHtmlContent] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [serviceStatus, setServiceStatus] = useState<PluginServiceStatus | null>(null);
  const [serviceActionLoading, setServiceActionLoading] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const fetchHtml = async () => {
    setLoading(true);
    setError(null);
    try {
      const html = await invoke<string>('load_plugin_html', { pluginId: plugin.id });
      setHtmlContent(html);
    } catch (err: any) {
      console.error('Failed to load plugin html:', err);
      setError(typeof err === 'string' ? err : err?.message || 'Impossibile caricare Plugin index.html');
    } finally {
      setLoading(false);
    }
  };

  const fetchServiceStatus = async () => {
    if (!plugin.service) return;
    try {
      const res = await invoke<PluginServiceStatus>('get_plugin_service_status', { pluginId: plugin.id });
      setServiceStatus(res);
      iframeRef.current?.contentWindow?.postMessage(
        {
          type: 'OPENREVO_PLUGIN_SERVICE_STATUS',
          payload: res,
        },
        '*'
      );
    } catch (e) {
      console.warn('[PluginTabHost] Failed to query service status:', e);
    }
  };

  const handleStartService = async () => {
    if (serviceActionLoading) return;
    setServiceActionLoading(true);
    setServiceStatus((prev) => (prev ? { ...prev, status: 'starting' } : { plugin_id: plugin.id, status: 'starting' }));
    try {
      const res = await invoke<PluginServiceStatus>('start_plugin_service', { pluginId: plugin.id });
      setServiceStatus(res);
      iframeRef.current?.contentWindow?.postMessage(
        {
          type: 'OPENREVO_PLUGIN_SERVICE_STATUS',
          payload: res,
        },
        '*'
      );
    } catch (e: any) {
      const errStatus: PluginServiceStatus = {
        plugin_id: plugin.id,
        status: 'error',
        code: 'SPAWN_ERROR',
        message: typeof e === 'string' ? e : e?.message || 'Errore all’avvio del servizio',
      };
      setServiceStatus(errStatus);
      iframeRef.current?.contentWindow?.postMessage(
        {
          type: 'OPENREVO_PLUGIN_SERVICE_STATUS',
          payload: errStatus,
        },
        '*'
      );
    } finally {
      setServiceActionLoading(false);
    }
  };

  const handleStopService = async () => {
    if (serviceActionLoading) return;
    setServiceActionLoading(true);
    try {
      const res = await invoke<PluginServiceStatus>('stop_plugin_service', { pluginId: plugin.id });
      setServiceStatus(res);
      iframeRef.current?.contentWindow?.postMessage(
        {
          type: 'OPENREVO_PLUGIN_SERVICE_STATUS',
          payload: res,
        },
        '*'
      );
    } catch (e: any) {
      console.error('[PluginTabHost] Failed to stop service:', e);
    } finally {
      setServiceActionLoading(false);
    }
  };

  useEffect(() => {
    fetchHtml();
    if (plugin.service) {
      fetchServiceStatus();
      if (plugin.service.auto_start) {
        handleStartService();
      }
    }
  }, [plugin.id]);

  // Push telemetry snapshot to iframe whenever status updates
  useEffect(() => {
    if (!iframeRef.current || !iframeRef.current.contentWindow) return;
    try {
      iframeRef.current.contentWindow.postMessage(
        {
          type: 'OPENREVO_TELEMETRY',
          payload: status,
        },
        '*'
      );
    } catch (_) {}
  }, [status]);

  // Handle postMessage from sandboxed plugin iframe
  useEffect(() => {
    const handleMessage = async (e: MessageEvent) => {
      // Security: Only accept messages intended for OpenRevo
      if (!e.data || typeof e.data !== 'object' || !e.data.action) return;

      const { action, payload } = e.data;
      try {
        switch (action) {
          case 'SET_POWER_MODE':
            if (payload?.mode) {
              await invoke('set_power_mode', { mode: payload.mode as PowerMode });
            }
            break;
          case 'SET_FAN_BOOST':
            if (typeof payload?.enable === 'boolean') {
              await invoke('set_fan_boost', { enable: payload.enable });
            }
            break;
          case 'SET_BATTERY_LIMIT':
            if (typeof payload?.limit === 'number') {
              await invoke('set_battery_limit', { limit: payload.limit });
            }
            break;
          case 'START_PLUGIN_SERVICE':
            await handleStartService();
            break;
          case 'STOP_PLUGIN_SERVICE':
            await handleStopService();
            break;
          case 'GET_PLUGIN_SERVICE_STATUS':
            await fetchServiceStatus();
            break;
          case 'GET_SHORTCUTS':
            {
              const list = await invoke('get_registered_shortcuts');
              iframeRef.current?.contentWindow?.postMessage({ type: 'OPENREVO_SHORTCUTS', payload: list }, '*');
            }
            break;
          case 'REGISTER_SHORTCUT':
            if (payload) {
              const res = await invoke('register_custom_shortcut', { binding: payload });
              iframeRef.current?.contentWindow?.postMessage({ type: 'OPENREVO_SHORTCUT_REGISTERED', success: res }, '*');
            }
            break;
          case 'UNREGISTER_SHORTCUT':
            if (payload?.id) {
              const res = await invoke('unregister_custom_shortcut', { id: payload.id });
              iframeRef.current?.contentWindow?.postMessage({ type: 'OPENREVO_SHORTCUT_UNREGISTERED', success: res }, '*');
            }
            break;
          case 'TRIGGER_SHORTCUT_ACTION':
            if (payload?.action) {
              await invoke('trigger_shortcut_action', { action: payload.action, osd: payload.osd });
            }
            break;
          case 'GET_RAW_EC_CAPABILITIES':
            {
              const caps = await invoke('get_raw_ec_capabilities');
              iframeRef.current?.contentWindow?.postMessage({ type: 'OPENREVO_RAW_EC_CAPABILITIES', payload: caps }, '*');
            }
            break;
          case 'RAW_EC_READ':
            if (payload) {
              try {
                const val = await invoke('raw_ec_read', { request: payload });
                iframeRef.current?.contentWindow?.postMessage({ type: 'OPENREVO_RAW_EC_READ_RESULT', success: true, payload: val }, '*');
              } catch (e: any) {
                iframeRef.current?.contentWindow?.postMessage({ type: 'OPENREVO_RAW_EC_READ_RESULT', success: false, error: String(e) }, '*');
              }
            }
            break;
          case 'RAW_EC_WRITE':
            if (payload) {
              try {
                const ok = await invoke('raw_ec_write', { request: payload });
                iframeRef.current?.contentWindow?.postMessage({ type: 'OPENREVO_RAW_EC_WRITE_RESULT', success: true, payload: ok }, '*');
              } catch (e: any) {
                iframeRef.current?.contentWindow?.postMessage({ type: 'OPENREVO_RAW_EC_WRITE_RESULT', success: false, error: String(e) }, '*');
              }
            }
            break;
          case 'RAW_MAILBOX_INVOKE':
            if (payload) {
              try {
                const out = await invoke('raw_mailbox_invoke', { request: payload });
                iframeRef.current?.contentWindow?.postMessage({ type: 'OPENREVO_RAW_MAILBOX_RESULT', success: true, payload: out }, '*');
              } catch (e: any) {
                iframeRef.current?.contentWindow?.postMessage({ type: 'OPENREVO_RAW_MAILBOX_RESULT', success: false, error: String(e) }, '*');
              }
            }
            break;
          default:
            break;
        }
      } catch (err) {
        console.warn('[PluginTabHost] Sandbox message dispatch failed:', err);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [plugin.id, serviceActionLoading]);

  const handleOpenPluginsDir = async () => {
    try {
      await invoke('open_plugins_dir');
    } catch (_) {}
  };

  const handlePopOut = async () => {
    try {
      await invoke('open_custom_widget', { pluginId: plugin.id });
    } catch (err) {
      console.error('Failed to open detached widget window:', err);
    }
  };

  if (loading) {
    return (
      <div
        style={{
          width: '100%',
          height: '100%',
          minHeight: '400px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '12px',
          color: 'var(--text-muted)',
        }}
      >
        <Loader2 size={28} className="animate-spin" />
        <span style={{ fontSize: '13px' }}>Caricamento pannello plugin [{plugin.name}]...</span>
      </div>
    );
  }

  if (error || !htmlContent) {
    return (
      <div className="sys-page">
        <div className="glass-card" style={{ maxWidth: '640px', margin: '40px auto', textAlign: 'center', padding: '32px 24px' }}>
          <div style={{ display: 'inline-flex', padding: '12px', borderRadius: '50%', background: 'rgba(239, 68, 68, 0.15)', color: 'var(--status-error)', marginBottom: '16px' }}>
            <AlertCircle size={32} />
          </div>
          <h3 style={{ margin: '0 0 8px 0', fontSize: '16px', color: 'var(--text-primary)' }}>Errore di caricamento del plugin</h3>
          <p style={{ margin: '0 0 20px 0', fontSize: '13px', color: 'var(--text-muted)', lineHeight: '1.5' }}>
            {error || 'File index.html mancante nella cartella del plugin. Verifica la cartella o consulta i plugin di terze parti di OpenRevo.'}
          </p>
          <div style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
            <button onClick={fetchHtml} className="toggle-btn">
              <RotateCcw size={13} />
              <span>Riprova</span>
            </button>
            <button onClick={handleOpenPluginsDir} className="toggle-btn active-indigo">
              <FolderOpen size={13} />
              <span>Apri cartella plugin</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        minHeight: '600px',
        display: 'flex',
        flexDirection: 'column',
        borderRadius: 'var(--radius-md)',
        overflow: 'hidden',
        background: 'var(--surface-overlay)',
        border: '1px solid var(--border-medium)',
      }}
    >
      {/* Tab Header Toolstrip with Pop-out Action */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '8px 14px',
          background: 'var(--surface-card)',
          borderBottom: '1px solid var(--border-subtle)',
          flexShrink: 0,
        }}
      >
        <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-primary)' }}>
          {plugin.name}
        </span>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          {plugin.service && (
            <div className="plugin-service-group">
              <div
                className="plugin-service-pill"
                title={
                  serviceStatus?.status === 'error'
                    ? `${serviceStatus.message || 'Errore all’avvio'}${serviceStatus.detail ? ` (${serviceStatus.detail})` : ''}`
                    : undefined
                }
              >
                <span className={`plugin-service-dot ${serviceStatus?.status || 'stopped'}`} />
                <span>
                  {serviceActionLoading
                    ? 'medio...'
                    : serviceStatus?.status === 'running'
                    ? `servizioOnline${serviceStatus.port ? ` :${serviceStatus.port}` : ''}`
                    : serviceStatus?.status === 'error'
                    ? 'servizioAnomalia'
                    : 'servizioEsegui'}
                </span>
              </div>

              {serviceStatus?.status === 'running' ? (
                <button
                  onClick={handleStopService}
                  disabled={serviceActionLoading}
                  className="toggle-btn"
                  title="ArrestaPluginLocaleservizio"
                  style={{ height: '22px', padding: '0 8px', fontSize: '11px' }}
                >
                  <Square size={10} />
                  <span>Arresta</span>
                </button>
              ) : (
                <button
                  onClick={handleStartService}
                  disabled={serviceActionLoading}
                  className="toggle-btn active-emerald"
                  title="PluginLocaleservizio"
                  style={{ height: '22px', padding: '0 8px', fontSize: '11px' }}
                >
                  {serviceActionLoading ? (
                    <Loader2 size={10} className="animate-spin" />
                  ) : (
                    <Play size={10} />
                  )}
                  <span>Avvia servizio</span>
                </button>
              )}
            </div>
          )}

          <button
            onClick={fetchHtml}
            className="toggle-btn"
            title="Carica nuovo plugin"
            style={{ height: '26px', padding: '0 10px', fontSize: '11px' }}
          >
            <RotateCcw size={12} />
            <span>Aggiorna</span>
          </button>
          <button
            onClick={handlePopOut}
            className="toggle-btn active-indigo"
            title="Esecuzione in finestra, utile per giochi o comandi principali"
            style={{ height: '26px', padding: '0 10px', fontSize: '11px' }}
          >
            <ExternalLink size={12} />
            <span>Esegui in finestra indipendente</span>
          </button>
        </div>
      </div>

      <iframe
        ref={iframeRef}
        srcDoc={htmlContent}
        title={plugin.name}
        sandbox="allow-scripts allow-forms allow-same-origin"
        style={{
          width: '100%',
          height: '100%',
          border: 'none',
          background: 'transparent',
          flex: 1,
        }}
        onLoad={() => {
          // Push initial telemetry after iframe DOM has loaded
          try {
            iframeRef.current?.contentWindow?.postMessage(
              {
                type: 'OPENREVO_TELEMETRY',
                payload: status,
              },
              '*'
            );
            if (serviceStatus) {
              iframeRef.current?.contentWindow?.postMessage(
                {
                  type: 'OPENREVO_PLUGIN_SERVICE_STATUS',
                  payload: serviceStatus,
                },
                '*'
              );
            }
          } catch (_) {}
        }}
      />
    </div>
  );
};
