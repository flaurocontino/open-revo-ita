import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { HardwareState } from '../../types/hardware';

export interface GpuPresetReferenceCardProps {
  presets?: HardwareState['power_presets'];
  isDeclarative?: boolean;
}

export const GpuPresetReferenceCard: React.FC<GpuPresetReferenceCardProps> = ({ presets, isDeclarative }) => {
  return (
    <div
      className="tuning-sub-card"
      style={{
        marginTop: 'auto',
        padding: '10px 12px',
        border: '1px solid var(--border-subtle)',
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '5px',
          fontSize: '11px',
          fontWeight: 700,
          color: 'var(--status-warn)',
          whiteSpace: 'nowrap',
        }}
      >
        <AlertTriangle size={13} className="shrink-0" />
        <span>Configurazione predefinita del consumo energetico</span>
        {presets?.hardware_read && (
          <span style={{ fontSize: '10px', color: 'var(--status-ok)', fontWeight: 600, marginLeft: 'auto' }}>
            {isDeclarative ? 'Hardware predefinito' : 'EC Hardware'}
          </span>
        )}
      </div>
      <div style={{ fontSize: '10.5px', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
        {presets?.hardware_read ? (
          <>
            <div>
              • Profilo CPU predefinito: Ufficio {presets.office_pl1} W / Bilanciato {presets.balance_pl1} W / Estremo {presets.turbo_pl1} W
            </div>
            <div>
              • Profilo GPU predefinito: base {presets.base_tgp} W + DB {presets.max_db} W (predefinito {presets.base_tgp + presets.max_db} W)
            </div>
          </>
        ) : (
          <>
            <div>• CPU consigliato:  PL1 45W~75W /  PL2 75W~115W</div>
            <div>• GPU consigliato: base Base TGP + DB 15W~25W dinamico</div>
          </>
        )}
      </div>
    </div>
  );
};
