// Pure formatting utilities for GPU mode display — no React dependency.

export function formatGpuShort(name?: string, hasDgpu: boolean = true): string {
  if (!hasDgpu) {
    if (!name || name === 'Scheda grafica' || name === 'Scheda grafica ad alte prestazioni' || name === 'Scheda grafica sconosciuta') return 'Grafica integrata della CPU';
    return name
      .replace(/\(R\)/gi, '')
      .replace(/\(TM\)/gi, '')
      .replace(/Graphics/gi, '')
      .trim() || 'Grafica integrata della CPU';
  }
  if (!name) return 'Scheda grafica';
  const s = name
    .replace(/NVIDIA\s+GeForce\s+/gi, '')
    .replace(/\s+Laptop\s+GPU/gi, '')
    .trim();
  return s || 'Scheda grafica';
}

export function formatCpuShort(name?: string): string {
  if (!name) return 'Hardware generico';
  return name
    .replace(/\(R\)/gi, '')
    .replace(/\(TM\)/gi, '')
    .replace(/14th Gen /gi, '')
    .replace(/13th Gen /gi, '')
    .replace(/12th Gen /gi, '')
    .replace(/Processor/gi, '')
    .trim();
}

export function getModeHexDisplay(mode: string, platform?: string): string {
  const isAmd = platform === 'amd';
  switch (mode) {
    case 'dgpu':   return isAmd ? '0x01' : '0x02';
    case 'hybrid': return isAmd ? '0x00' : '0x04';
    case 'igpu':   return isAmd ? '0x02' : '0x01';
    default:       return '--';
  }
}

export function getModeTitle(mode: string): string {
  switch (mode) {
    case 'dgpu':   return 'Collegamento diretto GPU';
    case 'hybrid': return 'Output ibrido';
    case 'igpu':   return 'Modalità grafica integrata';
    default:       return 'Modalità sconosciuta';
  }
}
