import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import {
  Puzzle,
  FolderOpen,
  RotateCcw,
  Boxes,
  Layers,
} from 'lucide-react';
import { HardwareState } from '../types/hardware';
import { RevBadge, RevSwitch } from './ui';
import { BUILTIN_MODULE_SLOTS, BuiltinModuleSlot } from '../plugins/plugin_manifest';

export interface PluginServiceConfig {
  executable: string;
  args?: string[];
  elevated?: boolean;
  auto_start?: boolean;
  auto_stop?: boolean;
  port?: number;
  health_url?: string;
}

export interface CustomPluginItem {
  id: string;
  name: string;
  version: string;
  author: string;
  description: string;
  plugin_type: string;
  enabled: boolean;
  dir_name: string;
  target_slot?: string;
  slot_height?: string;
  service?: PluginServiceConfig;
  shortcuts?: any[];
  watchers?: any[];
  permissions?: string[];
  min_host_version?: string;
  is_compatible?: boolean;
  compatibility_notice?: string;
}

export interface PluginsViewProps {
  status: HardwareState;
  moduleToggles?: Record<string, boolean>;
  onToggleModule?: (id: string, enabled: boolean) => void;
  waterCoolerEnabled?: boolean;
  onToggleWaterCooler?: (enabled: boolean) => void;
  activeSkin?: string | null;
  onApplySkin?: (skinId: string | null) => void;
  activeBackground?: string | null;
  onApplyBackground?: (backgroundId: string | null) => void;
  onCustomPluginsUpdated?: () => void;
}

export const PluginsView: React.FC<PluginsViewProps> = ({
  status,
  moduleToggles,
  onToggleModule,
  waterCoolerEnabled: propWaterCoolerEnabled,
  onToggleWaterCooler,
  activeSkin,
  onApplySkin,
  activeBackground,
  onApplyBackground,
  onCustomPluginsUpdated,
}) => {
  // Water cooler special toggle handling
  const [waterCoolerEnabled, setWaterCoolerEnabled] = useState<boolean>(() => {
    return propWaterCoolerEnabled ?? status.water_cooler_enabled ?? status.support_flags?.has_water_cooler ?? false;
  });
  const [togglingWaterCooler, setTogglingWaterCooler] = useState(false);

  useEffect(() => {
    if (typeof propWaterCoolerEnabled === 'boolean') {
      setWaterCoolerEnabled(propWaterCoolerEnabled);
    } else if (typeof status.water_cooler_enabled === 'boolean') {
      setWaterCoolerEnabled(status.water_cooler_enabled);
    }
  }, [propWaterCoolerEnabled, status.water_cooler_enabled]);

  const handleToggleWaterCooler = async () => {
    if (togglingWaterCooler) return;
    setTogglingWaterCooler(true);
    const nextVal = !waterCoolerEnabled;
    setWaterCoolerEnabled(nextVal);
    try {
      await invoke('set_water_cooler_enabled', { enabled: nextVal });
      if (onToggleWaterCooler) {
        onToggleWaterCooler(nextVal);
      }
    } catch (e) {
      console.error('Failed to toggle water cooler module:', e);
      setWaterCoolerEnabled(!nextVal);
    } finally {
      setTogglingWaterCooler(false);
    }
  };

  const isModuleOn = (id: string) => {
    if (id === 'water') {
      return waterCoolerEnabled;
    }
    return moduleToggles?.[id] ?? true;
  };

  const handleModuleSwitch = (slot: BuiltinModuleSlot, nextVal: boolean) => {
    if (slot.isEssential) return;
    if (slot.id === 'water') {
      handleToggleWaterCooler();
      return;
    }
    if (onToggleModule) {
      onToggleModule(slot.id, nextVal);
    }
  };

  // Custom Plugins State
  const [customPlugins, setCustomPlugins] = useState<CustomPluginItem[]>([]);
  const [loadingCustom, setLoadingCustom] = useState(false);
  const [currentSkin, setCurrentSkin] = useState<string | null>(activeSkin || null);
  const [currentBg, setCurrentBg] = useState<string | null>(activeBackground || null);

  useEffect(() => {
    setCurrentSkin(activeSkin || null);
  }, [activeSkin]);

  useEffect(() => {
    setCurrentBg(activeBackground || null);
  }, [activeBackground]);

  const fetchCustomPlugins = async (isManual = false) => {
    setLoadingCustom(true);
    try {
      const res = await invoke<CustomPluginItem[]>('get_custom_plugins');
      const list = res || [];
      setCustomPlugins(list);

      if (isManual) {
        let currentSkin = activeSkin;
        let currentBg = activeBackground;
        try {
          const backendSkin = await invoke<string | null>('get_active_skin');
          if (backendSkin !== undefined) {
            currentSkin = backendSkin;
          }
          const backendBg = await invoke<string | null>('get_active_background');
          if (backendBg !== undefined) {
            currentBg = backendBg;
          }
        } catch (_) {}

        if (onApplySkin) {
          if (currentSkin && list.some((p) => p.id === currentSkin)) {
            onApplySkin(currentSkin);
          } else if (activeSkin) {
            onApplySkin(null);
          }
        }

        if (onApplyBackground) {
          if (currentBg && list.some((p) => p.id === currentBg)) {
            onApplyBackground(currentBg);
          } else if (activeBackground) {
            onApplyBackground(null);
          }
        }
      }

      if (onCustomPluginsUpdated) {
        onCustomPluginsUpdated();
      }
    } catch (err) {
      console.error('Failed to load custom plugins:', err);
    } finally {
      setLoadingCustom(false);
    }
  };

  useEffect(() => {
    fetchCustomPlugins();
  }, []);

  const handleOpenPluginsDir = async () => {
    try {
      await invoke('open_plugins_dir');
    } catch (err) {
      console.error('Failed to open plugins directory:', err);
    }
  };

  const handleToggleCustomPlugin = async (plugin: CustomPluginItem) => {
    if (plugin.plugin_type === 'skin') {
      const isCurrentlyActive = currentSkin === plugin.id;
      const targetSkin = isCurrentlyActive ? null : plugin.id;

      setCurrentSkin(targetSkin);
      setCustomPlugins((prev) =>
        prev.map((p) => {
          if (p.plugin_type === 'skin') {
            return { ...p, enabled: p.id === targetSkin };
          }
          return p;
        })
      );

      if (onApplySkin) {
        onApplySkin(targetSkin);
      }
      if (onCustomPluginsUpdated) {
        onCustomPluginsUpdated();
      }
      return;
    }

    if (plugin.plugin_type === 'background') {
      const isCurrentlyActive = currentBg === plugin.id;
      const targetBg = isCurrentlyActive ? null : plugin.id;

      setCurrentBg(targetBg);
      setCustomPlugins((prev) =>
        prev.map((p) => {
          if (p.plugin_type === 'background') {
            return { ...p, enabled: p.id === targetBg };
          }
          return p;
        })
      );

      if (onApplyBackground) {
        onApplyBackground(targetBg);
      }
      if (onCustomPluginsUpdated) {
        onCustomPluginsUpdated();
      }
      return;
    }

    if (plugin.is_compatible === false) {
      return;
    }

    const nextVal = !plugin.enabled;
    setCustomPlugins((prev) =>
      prev.map((p) => (p.id === plugin.id ? { ...p, enabled: nextVal } : p))
    );
    try {
      await invoke('set_custom_plugin_enabled', { id: plugin.id, enabled: nextVal });
      if (plugin.plugin_type === 'widget') {
        if (nextVal) {
          await invoke('open_custom_widget', { pluginId: plugin.id });
        } else {
          await invoke('close_custom_widget', { pluginId: plugin.id });
        }
      }
      if (onCustomPluginsUpdated) {
        onCustomPluginsUpdated();
      }
    } catch (err) {
      console.error('Failed to toggle custom plugin:', err);
      setCustomPlugins((prev) =>
        prev.map((p) => (p.id === plugin.id ? { ...p, enabled: !nextVal } : p))
      );
    }
  };

  // Builtin modules: Strictly exclude "system", "plugins", and "sponsor"
  const builtinSlots = BUILTIN_MODULE_SLOTS.filter(
    (slot) => slot.id !== 'system' && slot.id !== 'plugins' && slot.id !== 'sponsor'
  );

  return (
    <div className="sys-page">
      {/* 1. Plugin integrati */}
      <div className="glass-card">
        <div className="plugin-section-header">
          <div className="plugin-section-title-wrap">
            <div className="plugin-section-title">
              <Puzzle size={16} />
              <span>Plugin integrati</span>
              <RevBadge variant="accent">Safe-Mode </RevBadge>
            </div>
            <div className="plugin-section-desc">
              Plugin di sistema essenziale: attivarlo o disattivarlo. Quando è disattivato viene nascosto.
            </div>
          </div>
          <RevBadge variant="default"> {builtinSlots.length} </RevBadge>
        </div>

        <div className="plugins-list">
          {builtinSlots.map((slot) => {
            const Icon = slot.icon;
            const active = isModuleOn(slot.id);
            return (
              <div key={slot.id} className="plugin-item-card">
                <div className="plugin-item-left">
                  <div className={`plugin-item-icon-box ${active ? 'active' : ''}`}>
                    <Icon size={16} />
                  </div>
                  <div className="plugin-item-info">
                    <div className="plugin-item-header">
                      <span className="plugin-item-name">{slot.name}</span>
                      <span className="plugin-item-id">[{slot.id}]</span>
                    </div>
                    <span className="plugin-item-desc">{slot.description}</span>
                  </div>
                </div>

                <div className="plugin-item-controls">
                  <RevSwitch
                    checked={active}
                    onChange={(val) => handleModuleSwitch(slot, val)}
                    disabled={slot.id === 'water' && togglingWaterCooler}
                    size="sm"
                    activeColor="var(--status-ok)"
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. Plugin personalizzati */}
      <div className="glass-card">
        <div className="plugin-section-header">
          <div className="plugin-section-title-wrap">
            <div className="plugin-section-title">
              <Boxes size={16} />
              <span>Plugin personalizzati</span>
              <RevBadge variant="info">Estensione comunitaria</RevBadge>
            </div>
            <div className="plugin-section-desc">
              Supporta il caricamento da cartelle con plugin desktop, servizi automatici e altre estensioni, in modalità sicura
            </div>
          </div>

          <div className="sys-row-controls">
            <button
              onClick={handleOpenPluginsDir}
              className="toggle-btn"
              title="Apri la cartella dei plugin (%APPDATA%\OpenRevo\plugins)"
            >
              <FolderOpen size={13} />
              <span>Apri cartella plugin</span>
            </button>
            <button
              onClick={() => fetchCustomPlugins(true)}
              disabled={loadingCustom}
              className="toggle-btn"
              title="Aggiorna la lista dei plugin"
            >
              <RotateCcw size={13} className={loadingCustom ? 'animate-spin' : ''} />
              <span>Aggiorna</span>
            </button>
          </div>
        </div>

        {customPlugins.length === 0 ? (
          <div className="plugin-empty-state">
            <div className="plugin-empty-icon">
              <Boxes size={24} />
            </div>
            <div className="plugin-empty-title">Nessun plugin personalizzato di terze parti rilevato</div>
            <div className="plugin-empty-desc">
               Trova i plugin cercando manifest.json o file .rhai nella cartella dei plugin e seleziona Aggiorna per ricaricarli. Consulta i plugin di terze parti OpenRevo per i dettagli.
            </div>
            <button onClick={handleOpenPluginsDir} className="toggle-btn active-indigo">
              <FolderOpen size={13} />
              <span>Apri cartella plugin</span>
            </button>
          </div>
        ) : (
          <div className="plugins-list">
            {customPlugins.map((plugin) => {
              const isPluginActive =
                plugin.plugin_type === 'skin'
                  ? currentSkin === plugin.id
                  : plugin.plugin_type === 'background'
                  ? currentBg === plugin.id
                  : plugin.enabled;
              return (
                <div key={plugin.id} className="plugin-item-card">
                  <div className="plugin-item-left">
                    <div className={`plugin-item-icon-box ${isPluginActive ? 'active' : ''}`}>
                      <Layers size={16} />
                    </div>
                    <div className="plugin-item-info">
                      <div className="plugin-item-header">
                        <span className="plugin-item-name">{plugin.name}</span>
                        <span className="plugin-item-id">[{plugin.id}]</span>
                        <RevBadge variant="default">v{plugin.version}</RevBadge>
                        {plugin.plugin_type === 'skin' ? (
                          <RevBadge variant="accent">Tema finestra principale</RevBadge>
                        ) : plugin.plugin_type === 'background' ? (
                          <RevBadge variant="warning">Sfondo</RevBadge>
                        ) : plugin.plugin_type === 'tab' ? (
                          <RevBadge variant="info">Slot pannello</RevBadge>
                        ) : plugin.plugin_type === 'widget' ? (
                          <RevBadge variant="success">Widget desktop</RevBadge>
                        ) : plugin.plugin_type === 'slot' ? (
                          <RevBadge variant="accent">Micro-slot {plugin.target_slot ? `[${plugin.target_slot}]` : ''}</RevBadge>
                        ) : (
                          <RevBadge variant="default">{plugin.plugin_type}</RevBadge>
                        )}
                        {plugin.is_compatible === false ? (
                          <RevBadge variant="error" title={plugin.compatibility_notice}>
                            ⚠️ {plugin.compatibility_notice || `necessario OpenRevo v${plugin.min_host_version}+`}
                          </RevBadge>
                        ) : plugin.min_host_version ? (
                          <RevBadge variant="default" title={`Requisito minimo OpenRevo v${plugin.min_host_version}`}>
                            v{plugin.min_host_version}+
                          </RevBadge>
                        ) : null}
                      </div>
                      <span className="plugin-item-desc">{plugin.description}</span>
                      <div className="plugin-item-meta">
                        <span>Autore: {plugin.author}</span>
                        <span>Cartella: {plugin.dir_name}</span>
                      </div>
                    </div>
                  </div>

                  <div className="plugin-item-controls">
                    <RevSwitch
                      checked={isPluginActive}
                      onChange={() => handleToggleCustomPlugin(plugin)}
                      disabled={plugin.is_compatible === false}
                      size="sm"
                      activeColor="var(--status-ok)"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
