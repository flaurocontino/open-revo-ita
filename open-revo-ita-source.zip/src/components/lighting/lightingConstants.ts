export interface LightingState {
  kb_enabled: boolean;
  kb_effect: number;
  kb_brightness: number;
  kb_speed: number;
  kb_direction: number;
  kb_color: string;

  // Streamer & Custom Engine
  kb_engine?: 'hardware' | 'streamer' | 'custom';
  kb_fps?: number;
  streamer_effect?: number;
  custom_scale?: number;
  custom_reactive?: boolean;
  custom_script_id?: string;

  // Four-Zone Keyboard Colors
  kb_zones?: [string, string, string, string];

  lb_enabled: boolean;
  lb_effect: number;
  lb_brightness: number;
  lb_speed: number;
  lb_color: string;

  hinge_enabled: boolean;
  hinge_effect: number;
  hinge_brightness: number;
  hinge_speed: number;
  hinge_color: string;

  logo_enabled: boolean;
  logo_effect: number;
  logo_brightness: number;
  logo_color: string;

  sleep_minutes: number;
  ceremony_enabled?: boolean;
}

export interface KeyboardHardwareInfo {
  hardware_type: string; // 'PerKeyRgb' | 'FourZoneRgb' | 'SingleZoneRgb' | 'SingleColor' | 'None'
  has_ite8291: boolean;
  has_ite7001: boolean;
  has_ite7000?: boolean;
  has_front_lightbar?: boolean;
  is_ec_lightbar?: boolean;
  has_logo?: boolean;
  has_usb_logo?: boolean;
  is_ec_logo?: boolean;
  has_hinge?: boolean;
  is_ec_hinge?: boolean;
  is_four_zone?: boolean;
  description: string;
  brightness_level: number;
  is_on: boolean;
}

// 4-Zone RGB Keyboard Modes (Factory Hardware MCU Effects for ITE 048D:CE00)
export const FOURZONE_KEYBOARD_MODES = [
  { id: 1, name: 'Singola / quattro zone', desc: 'Colore fisso statico con configurazione personalizzata a 4 zone' },
  { id: 2, name: 'Respirazione monocromatica', desc: 'Respirazione fluida e sfumata' },
  { id: 3, name: 'Onda RGB', desc: 'Effetto su tutte e quattro le zone' },
  { id: 5, name: 'Ciclo arcobaleno', desc: 'Sincronizzazione fluida su quattro zone' },
  { id: 12, name: 'Lampeggio', desc: 'Lampeggio su quattro zone' },
  { id: 13, name: 'Effetto luminoso', desc: 'Effetto luminoso multiplo su quattro zone' },
];

// Factory Hardware MCU Built-in Effects (Direct ITE 8291 execution, 0% CPU)
export const KEYBOARD_MODES = [
  { id: 1, name: 'Colore fisso', desc: 'Colore fisso statico classico' },
  { id: 2, name: 'Respirazione monocromatica', desc: 'Respirazione fluida e sfumata' },
  { id: 3, name: 'Effetto luminoso', desc: 'Su tutta la tastiera' },
  { id: 4, name: 'Tasto', desc: 'Attivazione' },
  { id: 5, name: 'Arcobaleno', desc: 'Effetto fluido' },
  { id: 6, name: '', desc: 'tastomedio' },
  { id: 10, name: '', desc: '' },
  { id: 9, name: 'Tutta la tastiera', desc: 'Effetto su tutta la tastiera' },
  { id: 17, name: '', desc: '' },
  { id: 14, name: 'Aurora', desc: 'Aurora' },
  { id: 21, name: 'Alto', desc: 'WASD e posizione centrale alta' },
];

// BetterRGB 60FPS Streamer High-Refresh Effects (100+ Prefix Namespace to isolate from Hardware MCU 1..21)
export const STREAMER_OFFSET = 100;
export const STREAMER_MODES = [
  { id: 101, name: 'Onda (Wave)', desc: 'Effetto onda su tutta la tastiera con movimento fluido' },
  { id: 100, name: 'Respirazione (Breath)', desc: 'Onda sinusoidale alta con respirazione' },
  { id: 102, name: 'Increspatura (Ripple)', desc: 'Effetto increspatura fluido' },
  { id: 103, name: 'Sabbia (Quicksand)', desc: 'Effetto sabbia dinamico su quattro zone' },
  { id: 104, name: 'Corrente (Current)', desc: 'Effetto luminoso scorrevole' },
  { id: 105, name: ' (Wheel)', desc: 'Arcobaleno medio' },
  { id: 106, name: 'Arcobaleno (Rainbow)', desc: 'Sincronizzazione fluida su tutta la tastiera' },
  { id: 107, name: 'Matrice (Matrix)', desc: 'Effetto dinamico a cascata sulla matrice' },
  { id: 108, name: ' (Lightning)', desc: 'Effetto multiplo' },
  { id: 109, name: ' (Flame)', desc: 'Effetto nella parte inferiore' },
  { id: 110, name: 'Pioggia (Rain)', desc: 'Effetto pioggia luminosa sulla tastiera' },
  { id: 111, name: 'Effetto stellare (Sparkle)', desc: 'Lampeggi stellari su tutta la tastiera' },
  { id: 112, name: 'Doppio (Touch Current)', desc: 'Doppio impatto alto' },
  { id: 113, name: 'Colore fisso (Static)', desc: 'per singolo tasto' },
];

export const LIGHTBAR_MODES = [
  { id: 1, name: 'Colore fisso', desc: 'Colore fisso classico' },
  { id: 2, name: 'Respirazione energetica', desc: 'Respirazione su zona singola' },
  { id: 20, name: 'Respirazione arcobaleno', desc: 'Respirazione sfumata su tutta la barra' },
  { id: 3, name: 'Onda RGB', desc: 'Effetto luminoso fluido' },
  { id: 4, name: 'Dinamico', desc: 'Effetto luminoso medio dinamico' },
  { id: 6, name: 'Velocissimo', desc: 'Effetto luminoso su zona singola' },
  { id: 9, name: 'Effetto scorrimento RGB', desc: 'Effetto luminoso su tutta la barra' },
  { id: 10, name: 'lampeggio scintillante', desc: 'lampeggio' },
];

export const LOGO_MODES = [
  { id: 1, name: 'Colore fisso', desc: 'Logo Mechrevo classico' },
  { id: 2, name: 'Respirazione monocromatica', desc: 'Respirazione colorata ed energetica' },
  { id: 20, name: 'Respirazione arcobaleno', desc: 'Respirazione su tutta l’area del logo' },
  { id: 3, name: 'Onda RGB', desc: 'Onda fluida su tutto il logo' },
  { id: 4, name: 'Dinamico', desc: 'Effetto energetico dinamico' },
  { id: 6, name: '', desc: 'Effetto luminoso del logo' },
  { id: 9, name: 'Tutta la tastiera', desc: 'Effetto luminoso completo' },
];

// Single-point direct EC PWM badges (e.g. YAOSHI 16 / L16Pro / CANGLONG shield badge)
export const EC_LOGO_MODES = [
  { id: 1, name: 'Colore fisso', desc: 'Logo dello scudo statico' },
  { id: 2, name: 'Respirazione energetica', desc: 'Logo dello scudo con respirazione' },
  { id: 20, name: 'Respirazione arcobaleno', desc: 'Logo dello scudo con respirazione sfumata' },
];

export const PRESET_COLORS = [
  { name: '', hex: '#00FFFF' },
  { name: '', hex: '#6366F1' },
  { name: 'Aurora verde', hex: '#10B981' },
  { name: 'Rosso', hex: '#EF4444' },
  { name: 'Cyber', hex: '#F59E0B' },
  { name: '', hex: '#EC4899' },
  { name: 'Blu', hex: '#3B82F6' },
  { name: '', hex: '#FFFFFF' },
];

export const SLEEP_OPTIONS = [
  { label: 'Non spegnere', value: 0 },
  { label: '1 minuto', value: 1 },
  { label: '5 minuti', value: 5 },
  { label: '10 minuti', value: 10 },
  { label: '15 minuti', value: 15 },
  { label: '30 minuti', value: 30 },
];

export interface BrfxScript {
  id: string;
  name: string;
  author: string;
  description: string;
  version?: string;
  speed: number;       // 0.2 ~ 3.0
  scale: number;       // 0.5 ~ 2.5
  direction: number;   // 0: R, 1: L, 2: U, 3: D
  reactive: boolean;   // Keypress reaction
  color: string;       // "#RRGGBB"
  code: string;
  filePath?: string;
  builtinEffectId?: number; // Corresponding native engine effect ID (e.g. 200, 201, 202)
  customText?: string;
}

