import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { Cpu, Check, RotateCcw, Loader2 } from 'lucide-react';

export interface LightingHardwareOverride {
  enabled: boolean;
  keyboard: string;   // "auto" | "per_key" | "four_zone" | "single_zone" | "single_white" | "none"
  front_bar: string;  // "auto" | "present" | "none"
  ambient: string;    // "auto" | "vent" | "shoulder" | "none"
  logo: string;       // "auto" | "letter" | "shield" | "none"
}

interface LightingRuntimeStatus {
  keyboard_engine: string;
  keyboard_online: boolean;
  keyboard_active: boolean;
  keyboard_fps: number;
  lightbar_online: boolean;
  lightbar_active: boolean;
  hinge_online: boolean;
  hinge_active: boolean;
  logo_online: boolean;
  logo_active: boolean;
  is_sleeping: boolean;
  hardware_override: LightingHardwareOverride;
  detected_baseline: LightingHardwareOverride;
}

interface LightingTopologyOverrideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplied?: () => void;
}

export const LightingTopologyOverrideModal: React.FC<LightingTopologyOverrideModalProps> = ({
  isOpen,
  onClose,
  onApplied,
}) => {
  const [config, setConfig] = useState<LightingHardwareOverride>({
    enabled: false,
    keyboard: 'auto',
    front_bar: 'auto',
    ambient: 'auto',
    logo: 'auto',
  });

  const [baseline, setBaseline] = useState<LightingHardwareOverride>({
    enabled: false,
    keyboard: 'auto',
    front_bar: 'auto',
    ambient: 'auto',
    logo: 'auto',
  });

  const [isApplying, setIsApplying] = useState(false);
  const [applyStep, setApplyStep] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    if (isOpen) {
      setErrorMessage('');
      invoke<LightingRuntimeStatus>('get_lighting_runtime_status')
        .then((status) => {
          if (status.hardware_override) {
            setConfig(status.hardware_override);
          }
          if (status.detected_baseline) {
            setBaseline(status.detected_baseline);
          }
        })
        .catch((err) => {
          console.error('[LightingTopology] Failed to fetch runtime status:', err);
        });
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSelect = (category: keyof LightingHardwareOverride, value: string) => {
    setErrorMessage('');
    setConfig((prev) => ({
      ...prev,
      enabled: true,
      [category]: value,
    }));
  };

  const handleResetToAuto = () => {
    setErrorMessage('');
    setConfig({
      enabled: false,
      keyboard: 'auto',
      front_bar: 'auto',
      ambient: 'auto',
      logo: 'auto',
    });
  };

  const handleApply = async () => {
    setIsApplying(true);
    setErrorMessage('');
    setApplyStep('In corso: driver sicuro con posizione hardware...');

    try {
      const isAllAuto =
        config.keyboard === 'auto' &&
        config.front_bar === 'auto' &&
        config.ambient === 'auto' &&
        config.logo === 'auto';

      const finalCfg: LightingHardwareOverride = {
        ...config,
        enabled: !isAllAuto,
      };

      await invoke('apply_lighting_hardware_override', {
        overrideCfg: finalCfg,
        override_cfg: finalCfg,
      });

      setConfig(finalCfg);
      setApplyStep('Applicazione hardware riuscita!');
      setTimeout(() => {
        setIsApplying(false);
        onClose();
        if (onApplied) onApplied();
      }, 500);
    } catch (err) {
      console.error('[LightingTopology] Failed to apply override:', err);
      setIsApplying(false);
      setApplyStep('');
      setErrorMessage(String(err));
    }
  };

  const effectiveKb = config.keyboard === 'auto' ? baseline.keyboard : config.keyboard;
  const effectiveFront = config.front_bar === 'auto' ? baseline.front_bar : config.front_bar;
  const effectiveAmb = config.ambient === 'auto' ? baseline.ambient : config.ambient;
  const effectiveLogo = config.logo === 'auto' ? baseline.logo : config.logo;

  let diffCount = 0;
  if (config.keyboard !== 'auto' && config.keyboard !== baseline.keyboard) diffCount++;
  if (config.front_bar !== 'auto' && config.front_bar !== baseline.front_bar) diffCount++;
  if (config.ambient !== 'auto' && config.ambient !== baseline.ambient) diffCount++;
  if (config.logo !== 'auto' && config.logo !== baseline.logo) diffCount++;

  return (
    <div className="sys-modal-backdrop" onClick={onClose}>
      <div
        className="sys-modal-card"
        style={{ maxWidth: '840px', width: '94%', overflow: 'visible' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sys-modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div
              className="sys-modal-icon-badge"
              style={{ background: 'var(--status-info-dim)', color: 'var(--status-info)' }}
            >
              <Cpu size={18} />
            </div>
            <div>
              <div className="sys-modal-title" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span>Correzione manuale della topologia hardware delle luci</span>
                <span
                  style={{
                    fontSize: '10.5px',
                    fontWeight: 600,
                    color: 'var(--status-info)',
                    background: 'var(--status-info-dim)',
                    padding: '1px 7px',
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid var(--status-info)',
                  }}
                >
                  adattivo
                </span>
              </div>
              <div className="sys-modal-subtitle">
                Il rilevamento automatico può non identificare dispositivi fisici aggiuntivi. Selezionare manualmente i dispositivi e fare riferimento alle informazioni hardware del modello.
              </div>
            </div>
          </div>
        </div>

        {}
        <div className="sys-modal-body" style={{ overflow: 'visible', padding: '14px 20px' }}>
          {errorMessage && (
            <div
              style={{
                marginBottom: '12px',
                padding: '8px 12px',
                borderRadius: 'var(--radius-sm)',
                background: 'var(--status-error-dim)',
                color: 'var(--status-error)',
                fontSize: '12px',
                border: '1px solid var(--status-error)',
              }}
            >
              ApplicaErrore: {errorMessage}
            </div>
          )}
          <div className="topology-container">

            {}
            <div className="topology-row">
              <div className="topology-row-left">
                <span className="topology-row-title">⌨️ 1. Hardware retroilluminazione tastiera</span>
                <span className="topology-row-hint">
                  rilevamento automatico: <strong>{baseline.keyboard || 'Medio rilevato'}</strong>
                </span>
              </div>
              <div className="topology-radio-group">
                {}
                <div
                  className={`topology-pill ${effectiveKb === 'per_key' ? 'selected' : ''}`}
                  onClick={() => handleSelect('keyboard', 'per_key')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">RGB per singolo tasto RGB</span>
                  {baseline.keyboard === 'per_key' && <span className="topology-badge-auto">automatico</span>}
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>RGB per singolo tasto RGB</span>
                      <span className="topology-tip-chip">048D:600B</span>
                    </div>
                    <p className="topology-tip-desc">Illuminazione per singolo tasto con effetti BetterRGB fino a 60 FPS e personalizzazione.</p>
                    <div className="topology-tip-example">Modelli tipici: YaoShi 16 Pro/Ultra, CangLong 16 e altri modelli alti</div>
                  </div>
                </div>

                {}
                <div
                  className={`topology-pill ${effectiveKb === 'four_zone' ? 'selected' : ''}`}
                  onClick={() => handleSelect('keyboard', 'four_zone')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">4zona RGB</span>
                  {baseline.keyboard === 'four_zone' && <span className="topology-badge-auto">automatico</span>}
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>4zona RGB Hardware</span>
                      <span className="topology-tip-chip">048D:CE00</span>
                    </div>
                    <p className="topology-tip-desc">Tastiera con quattro zone fisiche, effetti hardware e respirazione.</p>
                    <div className="topology-tip-example">Modelli tipici: Mechrevo16, X10 Pro, Aurora</div>
                  </div>
                </div>

                {}
                <div
                  className={`topology-pill ${effectiveKb === 'single_zone' ? 'selected' : ''}`}
                  onClick={() => handleSelect('keyboard', 'single_zone')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">RGB a zona singola</span>
                  {baseline.keyboard === 'single_zone' && <span className="topology-badge-auto">automatico</span>}
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>RGB a zona singola ()</span>
                      <span className="topology-tip-chip">EC RAM PWM</span>
                    </div>
                    <p className="topology-tip-desc">Controllo diretto EC della scheda madre su tutta la tastiera; supporta colore fisso, respirazione e arcobaleno sfumato.</p>
                    <div className="topology-tip-example">Modelli tipici: AuroraX, YaoShi 15 con zona singola, KuangShi G16</div>
                  </div>
                </div>

                {}
                <div
                  className={`topology-pill ${effectiveKb === 'single_white' ? 'selected' : ''}`}
                  onClick={() => handleSelect('keyboard', 'single_white')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">illuminazione bianca monocromatica</span>
                  {baseline.keyboard === 'single_white' && <span className="topology-badge-auto">automatico</span>}
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>illuminazione bianca monocromaticaretroilluminazione</span>
                      <span className="topology-tip-chip">EC 1932</span>
                    </div>
                    <p className="topology-tip-desc">LED bianchi con tre livelli: spento, debole (50%) o forte (100%).</p>
                    <div className="topology-tip-example">Modelli tipici: Wireless14X, Wireless15X e altrileggero</div>
                  </div>
                </div>

                {/* Disabilita */}
                <div
                  className={`topology-pill ${effectiveKb === 'none' ? 'selected' : ''}`}
                  onClick={() => handleSelect('keyboard', 'none')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">nessunretroilluminazione/Disabilita</span>
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>Nessuna retroilluminazione tastiera</span>
                      <span className="topology-tip-chip">Disabled</span>
                    </div>
                    <p className="topology-tip-desc">Disabilita la retroilluminazione o nasconde i controlli tastiera dalla sezione corrispondente.</p>
                  </div>
                </div>
              </div>
            </div>

            {}
            <div className="topology-row">
              <div className="topology-row-left">
                <span className="topology-row-title">🌊 2. anterioreBarra luminosa frontale</span>
                <span className="topology-row-hint">
                  rilevamento automatico: <strong>{baseline.front_bar === 'present' ? '' : 'Non rilevato'}</strong>
                </span>
              </div>
              <div className="topology-radio-group">
                <div
                  className={`topology-pill ${effectiveFront === 'present' ? 'selected' : ''}`}
                  onClick={() => handleSelect('front_bar', 'present')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">anterioreBarra luminosa frontale ()</span>
                  {baseline.front_bar === 'present' && <span className="topology-badge-auto">automatico</span>}
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>bordo anterioreeffetto luminoso</span>
                      <span className="topology-tip-chip">048D:7001 / EC</span>
                    </div>
                    <p className="topology-tip-desc">Zona luminosa sotto il touchpad; supporta effetti multipli e onde RGB.</p>
                    <div className="topology-tip-example">Modelli tipici: YaoShi 16, Mechrevo 16 e altri modelli con bordo anteriore</div>
                  </div>
                </div>

                <div
                  className={`topology-pill ${effectiveFront === 'none' ? 'selected' : ''}`}
                  onClick={() => handleSelect('front_bar', 'none')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">nessunBarra luminosa frontale ()</span>
                  {baseline.front_bar === 'none' && <span className="topology-badge-auto">automatico</span>}
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>Non rilevato</span>
                      <span className="topology-tip-chip">None</span>
                    </div>
                    <p className="topology-tip-desc">Se non è presente alcuna barra luminosa frontale, scegliere Disattivato.</p>
                  </div>
                </div>
              </div>
            </div>

            {}
            <div className="topology-row">
              <div className="topology-row-left">
                <span className="topology-row-title">💨 3. luce d'atmosfera</span>
                <span className="topology-row-hint">
                  rilevamento automatico: <strong>{baseline.ambient || 'Non rilevato'}</strong>
                </span>
              </div>
              <div className="topology-radio-group">
                <div
                  className={`topology-pill ${effectiveAmb === 'vent' ? 'selected' : ''}`}
                  onClick={() => handleSelect('ambient', 'vent')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">lucia laterale posteriore (sfiatoluce d'atmosfera)</span>
                  {baseline.ambient === 'vent' && <span className="topology-badge-auto">automatico</span>}
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>posteriorerigaluce d'atmosfera</span>
                      <span className="topology-tip-chip">048D:7000 / Hinge</span>
                    </div>
                    <p className="topology-tip-desc">Linea delle prese posteriori e configurazione classica del raffreddamento ad acqua.</p>
                    <div className="topology-tip-example">Modelli tipici: KuangShi16 Super Raffreddamento ad acquae altri</div>
                  </div>
                </div>

                <div
                  className={`topology-pill ${effectiveAmb === 'shoulder' ? 'selected' : ''}`}
                  onClick={() => handleSelect('ambient', 'shoulder')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">luci laterali (sincronizza)</span>
                  {baseline.ambient === 'shoulder' && <span className="topology-badge-auto">automatico</span>}
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>doppioluci laterali</span>
                      <span className="topology-tip-chip">IDZ Sync</span>
                    </div>
                    <p className="topology-tip-desc">Zona superiore della tastiera estesa lateralmente e collegata al pannello principale.</p>
                    <div className="topology-tip-example">Modelli tipici: Deepsea Ghost IDZ configurazionecolonna</div>
                  </div>
                </div>

                <div
                  className={`topology-pill ${effectiveAmb === 'none' ? 'selected' : ''}`}
                  onClick={() => handleSelect('ambient', 'none')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">Nessuna luce d’atmosfera (predefinito)</span>
                  {baseline.ambient === 'none' && <span className="topology-badge-auto">automatico</span>}
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>nessunluce d'atmosfera</span>
                      <span className="topology-tip-chip">None</span>
                    </div>
                    <p className="topology-tip-desc">Se il modello non ha prese o luci laterali, disattivare i controlli della luce ambiente.</p>
                  </div>
                </div>
              </div>
            </div>

            {}
            <div className="topology-row">
              <div className="topology-row-left">
                <span className="topology-row-title">✨ 4. A LOGO </span>
                <span className="topology-row-hint">
                  rilevamento automatico: <strong>{baseline.logo || 'Non rilevato'}</strong>
                </span>
              </div>
              <div className="topology-radio-group">
                <div
                  className={`topology-pill ${effectiveLogo === 'letter' ? 'selected' : ''}`}
                  onClick={() => handleSelect('logo', 'letter')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">testo LOGO (MECHREVO)</span>
                  {baseline.logo === 'letter' && <span className="topology-badge-auto">automatico</span>}
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>testo LOGO</span>
                      <span className="topology-tip-chip">USB NewLogo (35)</span>
                    </div>
                    <p className="topology-tip-desc">Compatibile con i modelli MECHREVO che usano un controller USB; supporta effetti luminosi avanzati.</p>
                    <div className="topology-tip-example">Modelli tipici: GM6IX0B, YaoShi</div>
                  </div>
                </div>

                <div
                  className={`topology-pill ${effectiveLogo === 'shield' ? 'selected' : ''}`}
                  onClick={() => handleSelect('logo', 'shield')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">scudo LOGO ()</span>
                  {baseline.logo === 'shield' && <span className="topology-badge-auto">automatico</span>}
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>scudologo luminoso</span>
                      <span className="topology-tip-chip">Motherboard EC 1963</span>
                    </div>
                    <p className="topology-tip-desc">Logo luminoso controllato direttamente dall’EC della scheda madre; supporta colore fisso, respirazione e effetti intermittenti.</p>
                    <div className="topology-tip-example">Modelli tipici: CangLong, YaoShi tutta colonna, AuroraX, Mechrevo</div>
                  </div>
                </div>

                <div
                  className={`topology-pill ${effectiveLogo === 'none' ? 'selected' : ''}`}
                  onClick={() => handleSelect('logo', 'none')}
                >
                  <div className="topology-dot" />
                  <span className="topology-pill-label">Nessun logo A</span>
                  {baseline.logo === 'none' && <span className="topology-badge-auto">automatico</span>}
                  <div className="topology-tip-icon">ⓘ</div>
                  <div className="topology-tooltip">
                    <div className="topology-tip-title">
                      <span>Retroilluminazione logo A assente</span>
                      <span className="topology-tip-chip">None</span>
                    </div>
                    <p className="topology-tip-desc">Disabilita il logo o seleziona il tipo A se il modello non dispone di effetti luminosi dedicati.</p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Footer Actions */}
        <div className="sys-modal-actions" style={{ justifyContent: 'space-between', padding: '12px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <button
              type="button"
              className="toggle-btn"
              onClick={handleResetToAuto}
              style={{ fontSize: '11px', display: 'flex', alignItems: 'center', gap: '5px' }}
            >
              <RotateCcw size={12} />
              <span>Ripristina tutto al rilevamento automatico</span>
            </button>
            <span style={{ fontSize: '11px', color: 'var(--text-dim)' }}>
              {diffCount === 0 ? (
                'conrilevamento automatico'
              ) : (
                <span style={{ color: 'var(--status-warning)', fontWeight: 600 }}>
                  {diffCount} manualecorrezione
                </span>
              )}
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <button
              type="button"
              className="toggle-btn"
              onClick={onClose}
              disabled={isApplying}
            >
              Annulla
            </button>
            <button
              type="button"
              className="toggle-btn active-indigo"
              onClick={handleApply}
              disabled={isApplying}
              style={{ fontWeight: 700 }}
            >
              {isApplying ? (
                <>
                  <Loader2 size={13} className="animate-spin" />
                  <span>{applyStep || 'Applicazione in corso...'}</span>
                </>
              ) : (
                <>
                  <Check size={13} />
                  <span>Salva nuovo hardware</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
