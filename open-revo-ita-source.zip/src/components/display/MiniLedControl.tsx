import React from 'react';
import { Layers } from 'lucide-react';

export interface MiniLedControlProps {
  enabled: boolean;
  isToggling: boolean;
  onToggle: (nextVal: boolean) => void;
}

/**
 */
export const MiniLedControl: React.FC<MiniLedControlProps> = ({
  enabled,
  isToggling,
  onToggle,
}) => {
  return (
    <div className="glass-card miniled-control-card">
      {/* Left: icon + label */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexShrink: 0 }}>
        <div className={`miniled-icon-badge ${enabled ? 'active' : ''}`}>
          <Layers className="w-4 h-4" />
        </div>
        <div>
          <div style={{ fontSize: '12.5px', fontWeight: 700, color: 'var(--text-primary)' }}>
            Attenuazione locale MiniLED dello schermo
          </div>
          <div style={{ fontSize: '10.5px', color: 'var(--text-dim)' }}>
            {enabled
              ? 'Stato attuale: attiva (prestazioni elevate)'
              : 'Stato attuale: disattiva (retroilluminazione uniforme dello schermo)'}
          </div>
        </div>
      </div>

      {/* Right: toggle switch */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexShrink: 0 }}>
        <button
          onClick={() => onToggle(!enabled)}
          disabled={isToggling}
          className={`miniled-toggle-switch ${enabled ? 'active' : ''}`}
          title={enabled ? 'Disattiva l’attenuazione locale MiniLED' : 'Attiva l’attenuazione locale MiniLED'}
          aria-label="Attiva o disattiva l’attenuazione locale MiniLED"
        >
          <div className="miniled-toggle-knob" />
        </button>
      </div>
    </div>
  );
};
