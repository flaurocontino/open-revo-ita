import React from 'react';
import {
  Gauge,
  Cpu,
  BatteryCharging,
  Palette,
  Droplets,
  Layers,
  Heart,
  Puzzle,
  LucideIcon,
} from 'lucide-react';
import { HardwareState } from '../types/hardware';

export type BuiltinTabId = 'overview' | 'gpu' | 'tuning' | 'lighting' | 'water' | 'system' | 'plugins' | 'sponsor';

export interface ModelCapabilities {
  id?: string;
  name?: string;
  form_factor?: 'thin_light' | 'gaming' | 'mini_pc' | string;
  ui_preset?: string;
  discrete_gpu?: boolean;
  water_cooling?: boolean;
  fan_custom_curve?: boolean;
  fan_independent_channels?: boolean;
  fan_ramp_rate?: boolean;
  fan_control_mode?: 'discrete_table_16' | 'direct_rpm_clamp' | 'fixed_boost_only' | 'none' | string;
  fan_boost_mode?: 'hardware_toggle' | 'direct_rpm_clamp' | string;
  max_fan_rpm?: number;
  cpu_vendor?: 'amd' | 'intel' | string;
  cpu_tuning_type?: 'intel_pl' | 'amd_smu' | 'none' | string;
  cpu_supports_fppt?: boolean;
  gpu_power_tuning_mode?: 'discrete_manual' | 'mode_locked' | 'none' | string;
  cpu_name?: string;
  battery_charge_limit?: boolean;
  battery_limit_mode?: string;
  fn_lock?: boolean;
  power_modes?: string[];
  power_mode_watts?: Record<string, number>;
  rgb_keyboard?: {
    supported?: boolean;
    type?: string;
    steps?: number[];
    sleep_timeout_supported?: boolean;
    hardware_autonomous?: boolean;
    hotkey_osd_only?: boolean;
  };
  is_adapted?: boolean;
  is_debug_mode?: boolean;
}

export interface ModuleSlotContext {
  status: HardwareState;
  isWaterCoolerEnabled: boolean;
  isCoolerConnected: boolean;
  moduleToggles?: Record<string, boolean>;
  capabilities?: ModelCapabilities;
}

export interface BuiltinModuleSlot {
  id: BuiltinTabId;
  name: string;
  tabClassName: string;
  order: number;
  icon: LucideIcon;
  iconClass?: string;
  description: string;
  /**
   */
  isEssential?: boolean;
  /**
   */
  isVisible: (ctx: ModuleSlotContext) => boolean;
  /**
   */
  renderBadge?: (ctx: ModuleSlotContext) => React.ReactNode;
}

export const BUILTIN_MODULE_SLOTS: BuiltinModuleSlot[] = [
  {
    id: 'overview',
    name: 'Stato',
    tabClassName: 'tab-overview',
    order: 10,
    icon: Gauge,
    description: 'Informazioni in tempo reale, cambio modalità e stato batteria',
    isVisible: () => true,
  },
  {
    id: 'gpu',
    name: 'Modalità scheda grafica',
    tabClassName: 'tab-gpu',
    order: 20,
    icon: Cpu,
    description: 'Collegamento diretto GPU, uscita ibrida MUX, overclock dinamico, luminosità dello schermo e calibrazione ICC',
    isVisible: () => true,
  },
  {
    id: 'tuning',
    name: 'Gestione alimentazione',
    tabClassName: 'tab-tuning',
    order: 30,
    icon: BatteryCharging,
    description: 'Limiti di alimentazione CPU PL1/PL2/PL4, curve doppie delle ventole e protezione termica',
    isVisible: () => true,
  },
  {
    id: 'lighting',
    name: 'Laboratorio effetti RGB',
    tabClassName: 'tab-lighting',
    order: 40,
    icon: Palette,
    description: 'Retroilluminazione a quattro zone, tastiera, logo ed effetti personalizzati',
    isVisible: (ctx) => {
      const type = ctx.capabilities?.rgb_keyboard?.type;
      return type !== 'none' && type !== 'monochrome_stepped';
    },
  },
  {
    id: 'water',
    name: 'Modulo raffreddamento ad acqua (BLE)',
    tabClassName: 'tab-water',
    order: 50,
    icon: Droplets,
    description: 'Controllo Bluetooth del raffreddamento esterno a bassa potenza e curve termiche intelligenti',
    isVisible: (ctx) => ctx.isWaterCoolerEnabled,
    renderBadge: (ctx) => {
      if (ctx.isCoolerConnected) {
        return <span className="cooler-tab-dot" />;
      }
      return (
        <span
          style={{
            fontSize: '9px',
            opacity: 0.65,
            padding: '0 4px',
            borderRadius: 'var(--radius-xs)',
            background: 'var(--surface-badge)',
          }}
        >
          
        </span>
      );
    },
  },
  {
    id: 'system',
    name: 'Sistema',
    tabClassName: 'tab-system',
    order: 60,
    icon: Layers,
    description: 'Configurazione hardware, OSD completo, avvio e parametri di sistema',
    isEssential: true,
    isVisible: () => true,
  },
  {
    id: 'plugins',
    name: 'Plugin',
    tabClassName: 'tab-plugins',
    order: 65,
    icon: Puzzle,
    description: 'Gestione dei plugin integrati e di terze parti',
    isEssential: true,
    isVisible: () => true,
  },
  {
    id: 'sponsor',
    name: 'Sostieni l’autore',
    tabClassName: 'tab-sponsor',
    order: 70,
    icon: Heart,
    iconClass: 'sponsor-tab-heart',
    description: 'Supporta lo sviluppatore e contribuisci alla compatibilità hardware',
    isEssential: true,
    isVisible: () => true,
  },
];

/**
 */
export const isSlotActive = (slot: BuiltinModuleSlot, ctx: ModuleSlotContext): boolean => {
  if (ctx.moduleToggles && ctx.moduleToggles[slot.id] === false) {
    return false;
  }
  return slot.isVisible(ctx);
};
